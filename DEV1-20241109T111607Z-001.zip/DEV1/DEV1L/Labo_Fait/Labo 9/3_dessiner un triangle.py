def afficher_triangle(nb):
    for z in range (nb):
        print("*"*(z+1))
nb=int(input("Entrez la taille du triangle,le triangle doit compter au minimum 3 lignes et au maximum 10 lignes :"))
while nb < 3 or nb > 10:
    nb=int(input("Entrez la taille du triangle,le triangle doit compter au minimum 3 lignes et au maximum 10 lignes :"))
afficher_triangle(nb)