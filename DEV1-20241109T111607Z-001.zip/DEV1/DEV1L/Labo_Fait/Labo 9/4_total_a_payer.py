prix=0
somme_totale=0
while prix != -1.0:
    prix=float(input("Entrez le prix unitaire : "))
    if prix != -1.0:
        quantite=int(input("Entrez la quantité d'articles : "))
        somme_totale += prix*quantite
print("La somme totale est de :",somme_totale,"€")
