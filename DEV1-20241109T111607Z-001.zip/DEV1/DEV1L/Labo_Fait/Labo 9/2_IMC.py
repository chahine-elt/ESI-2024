taille=float(input("Entrez la taille en m : "))
poids=float(input("Entrez le poids kg : "))
imc=poids/taille**2
print("L'IMC est de :",imc)