import math
lu=float(input("Entrez un nombre réel : "))
print("le plus petit entier supérieur ou égal au nombre lu est :",math.ceil(lu))
print("le plus grand entier inférieur ou égal au nombre lu est :",math.floor(lu))