def addition(l1,valeur):
    nouv_liste=[l1[i]+valeur for i in range(len(l1))]
    return nouv_liste
    
l1 = [1, 2, 3, 4, 5]
valeur = 2
print(addition(l1,valeur))