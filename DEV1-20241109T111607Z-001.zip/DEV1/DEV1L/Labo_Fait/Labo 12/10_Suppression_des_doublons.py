#a
def suppression_doublons(ma_liste):
    liste2=[]
    for i in ma_liste:
        if i not in liste2:
            liste2.append(i)
    return liste2
    
ma_liste=[7, 3, 3, 8, 8, 8, 7]
print(suppression_doublons(ma_liste))

#b
def suppression_doublons(ma_liste):
    for i in ma_liste:
        if ma_liste.count(i) > 1:
            for z in range(ma_liste.count(i)-1):
                ma_liste.remove(i)
    return ma_liste
    
ma_liste=[7, 3, 3, 8, 8, 8, 7]
print(suppression_doublons(ma_liste))