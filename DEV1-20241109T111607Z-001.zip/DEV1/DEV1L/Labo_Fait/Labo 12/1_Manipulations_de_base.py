>>> liste1=[0,1,2,3,4,5,6,7,8,9,10]
>>> len(liste1)
11

>>> 0 in liste1
True

>>> liste1.append(15)


>>> liste1.reverse()

>>> liste1[0:len(liste1)-1:2]

>>> liste4 = liste1[1:len(liste1)-1:2]
>>> liste4
[10, 8, 6, 4, 2]

>>> liste1.count(3)
1

>>> liste1.insert(1,7)
>>> liste1
[15, 7, 10, 7, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
#Nous faisons la difference avec l'id.

>>> liste1[2:4]=[10,12,14,16]
>>> liste1
[15, 7, 10, 12, 14, 16, 14, 16, 7, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

>>> liste2=liste1.copy()
>>> liste2
[15, 7, 10, 12, 14, 16, 14, 16, 7, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
>>> liste3 = liste1
#Nous faisons la difference avec l'id.

>>> dernier=liste1.pop()
>>> dernier
0

>>> quatrieme=liste1.pop(3)
>>> quatrieme
12

>>>liste1.sort()
>>> liste1
[1, 2, 3, 4, 5, 7, 7, 7, 8, 9, 12, 14, 14, 14, 14, 16, 16, 16, 16]
>>> liste1.sort(reverse=True)
>>> liste1

>>> liste1.index(0)

>>> liste1.index(liste1)

>>> liste1.index(15)
0
>>> liste1.index(20)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ValueError: 20 is not in list

>>> liste1.del(15)

>>> del liste[0]

>>> del.liste[0]

>>> del(liste[0])

>>> del(liste1[0])
>>> del(liste1[10])
>>> del(liste1[20])
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IndexError: list assignment index out of range

>>> liste1.extend(liste2[3:8])
>>> liste1
[7, 10, 14, 16, 14, 16, 7, 9, 8, 7, 5, 4, 3, 2, 1, 12, 14, 16, 14, 16]

>>> del(liste2)
>>> liste2

>>> del(liste[0])