def moyenne(ma_liste):
    moyenne=0
    for i in range (len(ma_liste)):
        moyenne+=ma_liste[i]
    moyenne/=len(ma_liste)
    return moyenne

ma_liste=[8.21,5.25,4.65,7.78,9.48,6.10]
print(moyenne(ma_liste))