def liste_elements_communs(l1,l2):
    l3=[]
    for i in range (len(l1)):
        if l1[i] in l2:
            l3.append(l1[i])
    return l3
        
l1=[1,7,9,50,448,122]
l2=[1,7,28,982,110,50]
print(liste_elements_communs(l1,l2))