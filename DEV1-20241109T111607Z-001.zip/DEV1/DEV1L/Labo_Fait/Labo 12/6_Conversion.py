def char_tp_int(liste):
    liste=[ord(liste[i])-97 for i in range (len(liste))]
    return liste
liste = ['b', 'o', 'n', 'j', 'o', 'u', 'r']
print(char_tp_int(liste))