import random
def liste_entiers_aleatoires(n,nmin,nmax):
    liste=[random.randint(nmin,nmax) for i in range(n)]
    return liste

n=int(input())
nmin=int(input())
nmax=int(input())
print(liste_entiers_aleatoires(n,nmin,nmax))