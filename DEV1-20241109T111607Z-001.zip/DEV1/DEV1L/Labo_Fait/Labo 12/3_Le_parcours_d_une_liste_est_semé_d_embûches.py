mots = ['Carottes', 'Poireaux', 'Tomates', 'Aubergines', 'Courgettes']
for m in mots[:] :
    mots.append(m)
print("1 : ",mots)

mots = ['Carottes', 'Poireaux', 'Tomates', 'Aubergines', 'Courgettes']
for m in mots :
    mots.append(m)
    print("2 : ",mots)
