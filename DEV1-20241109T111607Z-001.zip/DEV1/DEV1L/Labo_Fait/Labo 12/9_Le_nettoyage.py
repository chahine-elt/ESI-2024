def suppression_occurrences(ma_liste,mot):
    compteur=0
    for i in ma_liste:
        if mot in ma_liste: 
            ma_liste.remove(mot)
            compteur+=1
    return compteur
ma_liste=["coucou","salut","coucou","bonjour"]
mot= 'coucou'
print(suppression_occurrences(ma_liste,mot))
