mots = ['Carottes', 'Poireaux', 'Tomates', 'Aubergines', 'Courgettes']
mots = mots.append("Brocolis")
print(mots)