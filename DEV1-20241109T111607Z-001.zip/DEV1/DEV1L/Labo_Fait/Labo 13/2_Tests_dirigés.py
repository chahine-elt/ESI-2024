profs_dev1 = {
"A111": "bej", "A112": "mbr", "A121": "sre", "A122": "dbo", "A131": "abe",

"A132": "clg", "A211": "bej", "A212": "cuv", "A221": "sre", "A222": "sdr",

"A231": "hal", "A232": "nri", "A311": "bis", "A312": "clg", "A321": "cuv",

"A322": "hal", "A331": "srv", "A332": "gba", "A341": "pbt", "A342": "tni"
}
 
groupes_par_prof = {
"abe": 1, "bej": 2, "bis": 1, "clg": 2, "cuv": 2,

"dbo": 1, "gba": 1, "hal": 2, "mbr": 1, "nri": 1,

"pbt": 1, "sdr": 1, "sre": 2, "srv": 1, "tni": 1
}

une_personne = {

"prénom": "Guillaume",

"nom": "Apollinaire",

"naissance": (26, 8, 1880)
}

autre_personne = {

"prénom": "Jean-Jacques",

"nom": "Goldmann",

"naissance": (11, 10, 1951)
}

etudiants = {

52104: {

"prénom": "Guillaume",

"nom": "Apollinaire",

"groupe": "A321"

},

45371: {

"prénom": "Jean-Jacques",

"nom": "Goldmann",

"groupe": "A123"

}
}
print("▷ obtenir le prof du groupe A311")
print(profs_dev1["A311"])
print("▷ obtenir le nombre de groupes de Mme Cuvelier (cuv).")

print(groupes_par_prof["cuv"])
print("▷ obtenir le groupe de l’étudiant ayant le matricule 52104")

print(etudiants[52104]["groupe"])
print("▷ afficher tou·tes les enseignant·es de dev1 (sans doublons)")

liste_prof=[]
for prof in profs_dev1.values():
    if prof not in liste_prof:
        liste_prof.append(prof)
        print(prof)