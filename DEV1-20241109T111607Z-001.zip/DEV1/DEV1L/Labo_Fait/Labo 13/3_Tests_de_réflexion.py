Que se passe-t-il si on essaye de

▷ donner deux valeurs à une même clef ?
Une erreur

▷ donner la même valeur à deux clefs différentes ?
Cela fonctionne

▷ accéder (par exemple afficher) à une clef qui n’existe pas dans le dictionnaire ?
Une Erreur

▷ utiliser une liste comme clef ?
Une Erreur

▷ utiliser, dans le même dictionnaire, des clefs de types différents (par exemple une
chaîne et un booléen) ?
Cela fonctionne