def clefs_grand(data):
    liste_key=[]
    tmp=max(data.values())
    for key,value in data.items():
        if value > tmp:
            tmp = value
            liste_key.append(key)
        elif tmp == value:
            liste_key.append(key)
    return liste_key

def frequences(liste_entrees):
    liste_entrees=sorted(liste_entrees)
    liste_entree=[]
    dico_entrees={}
    for entree in liste_entrees:
        if entree not in liste_entree:
            liste_entree.append(entree)
            dico_entrees[entree]=liste_entrees.count(entree)
    return dico_entrees
  
entree=input("Entrez un mot (appuyer sur enter pour arreter) ")
liste_entrees=[]
while entree != "":
    liste_entrees.append(entree)
    entree=input("Entrez un mot (appuyer sur enter pour arreter) ")
    
print(clefs_grand(frequences(liste_entrees)))


