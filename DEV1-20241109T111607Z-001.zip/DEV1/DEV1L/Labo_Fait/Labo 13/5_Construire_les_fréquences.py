profs_dev1 = [
"bej", "mbr", "sre", "dbo", "abe",

"clg", "bej", "cuv", "sre", "sdr",

"hal", "nri", "bis", "clg", "cuv",

"hal", "srv", "gba", "pbt", "tni"
]

def frequences(profs_dev1):
    profs_dev1=sorted(profs_dev1)
    liste_profs=[]
    dico_profs={}
    for prof in profs_dev1:
        if prof not in liste_profs:
            liste_profs.append(prof)
            dico_profs[prof]=profs_dev1.count(prof)
    return dico_profs

print(frequences(profs_dev1))
    