horaire={"lundi":"math","mardi":"ints","mercredi":"intr"}
print(horaire)
print(horaire["lundi"])

horaire["lundi"]="DEVP"
print(horaire)
print(horaire["lundi"])

print("lundi" in horaire)
print("dimanche" in horaire)

for key in horaire:
    print(key)

for key,value in horaire.items():
    print(key,value)
    
print(horaire.get("lundi","DEVP"))

print(len(horaire))
print(list(horaire))
print(list(horaire.items()))
print(list(horaire.values()))
valeur=horaire.pop("lundi","DEVP")
print(valeur)
print(horaire)