data = {
"abe": 1, "bej": 2, "bis": 1, "clg": 2, "cuv": 2,

"dbo": 1, "gba": 1, "hal": 2, "mbr": 1, "nri": 1,

"pbt": 1, "sdr": 1, "sre": 2, "srv": 1, "tni": 1
}

def clefs_grand(data):
    liste_key=[]
    tmp=max(data.values())
    for key,value in data.items():
        if value > tmp:
            tmp = value
            liste_key.append(key)
        elif tmp == value:
            liste_key.append(key)
    return liste_key

print(clefs_grand(data))