#Affiche tout les nombres de 1 jusqu'au nombre taper par l'utilisateur
n = int(input("Entrez le dernier nombre à afficher : "))
compteur = 1
while compteur <= n:
    print(compteur)
    compteur+=1
   