#Affiche le nom du mois grace a àa position 
nb=int(input("Entrez le nombre du mois : "))
mois=["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"]
while nb <= 1 and nb >= 12:
    nb = int(input("Raté ! Essayez encore : "))
print(mois[nb-1])