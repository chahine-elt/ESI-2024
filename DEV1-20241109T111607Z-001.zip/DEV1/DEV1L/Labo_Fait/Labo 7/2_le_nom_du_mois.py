# les nombres pairs qui sont compris entre 1 et n ;
# les nombres de -n à n ;
# les multiples de 5 qui sont compris entre 1 et n ;
# les multiples de n compris entre 1 et 100 ;
n = int(input("Entrez le dernier nombre à afficher : "))
compteur=1
while compteur <= n:
    if compteur == 1:
        print("Les nombres pairs qui sont compris entre 1 et",n,":")
    if compteur%2 == 0:
        print(compteur)
    compteur+=1
print()
nb= -n             
while nb <= n:
    if nb == -n:
        print("les nombres de",-n,"à",n,":")
    print(nb) 
    nb+=1
print()    
compteur=1  
while compteur*5 <= n:
    if compteur == 1:
        print("les multiples de 5 qui sont compris entre 1 et",n,":") 
    print(compteur*5)
    compteur+=1
print()        
compteur=1      
while compteur*n <= 100:
    if compteur == 1:
        print("Les multiples de",n,"compris entre 1 et 100 : ") 
    print(compteur*n)
    compteur+=1