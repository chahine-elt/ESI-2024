#Demande à l'utilisateur de trouver le nombre secret et en
# fonction du nombre erroné entré par l’utilisateur, le programme afficher «trop petit» ou
# «trop grand»
import random
nombre_secret = random.randint(1,10)
essais = 0
print("L'ordinateur a choisi un nombre entre 1 et 10")
print("Vous allez devoir le deviner !")

nombre_utilisateur = int(input("Entrez un nombre:"))
while(nombre_utilisateur != nombre_secret):
    if nombre_utilisateur > nombre_secret:
        indice = "Trop grand ! "
        print(indice,end="")
        nombre_utilisateur = int(input("Essayez encore: "))
        essais+=1
       
    elif nombre_utilisateur < nombre_secret:
        indice = "Trop petit ! "
        print(indice,end="")
        nombre_utilisateur = int(input("Essayez encore: "))
        essais+=1
print("Bravo ! Vous avez trouvé le nombre secret en",essais,"essais.")