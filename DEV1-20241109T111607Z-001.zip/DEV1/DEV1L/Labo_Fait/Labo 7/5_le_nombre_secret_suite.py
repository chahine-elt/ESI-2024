#Demande à l'utilisateur de trouver le nombre secret
import random
nombre_secret = random.randint(1,10)
essais = 0
print("L'ordinateur a choisi un nombre entre 1 et 10")
print("Vous allez devoir le deviner !")

nombre_utilisateur = int(input("Entrez un nombre:"))
while(nombre_utilisateur != nombre_secret):
    nombre_utilisateur = int(input("Raté ! Essayez encore: "))
    essais+=1

print("Bravo ! Vous avez trouvé le nombre secret en",essais,"essais.")