#Affiche le nom du mois grace a àa position 
import random
nombre_secret = random.randint(1,10)
print("L'ordinateur a choisi un nombre entre 1 et 10")
print("Vous allez devoir le deviner !")

nombre_utilisateur = int(input("Entrez un nombre:"))

while(nombre_utilisateur != nombre_secret):
    nombre_utilisateur = int(input("Raté ! Essayez encore: "))

print("Bravo !")