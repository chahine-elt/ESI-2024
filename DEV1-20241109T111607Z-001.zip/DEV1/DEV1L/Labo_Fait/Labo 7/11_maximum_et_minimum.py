#Demande à l'utilisateur une série de nombres positifs qui se termine
#par -1 (valeur sentinelle). Le programme affiche le maximum et le minimum de la série.
nombre = int(input("Entrez un nombre positif : "))
liste = []
while nombre > -1 :
    nombre = int(input("Entrez un nombre positif : "))
    liste.append(nombre)
    sorted(liste)
print("Maximum :",liste[0])
print("Maximum :",liste[len(liste)-2])