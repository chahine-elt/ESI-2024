# Canevas d'un script lisant une suite de nombres au clavier et donne la somme
nb_valeurs = 0
valeur = int(input("Entrez une suite de nombre entier positifs, terminez par -1: "))
somme = 0
while(valeur > -1):
    nb_valeurs = nb_valeurs +1
    somme +=valeur
    valeur = int(input("Entrez une autre valeur (ou -1 pour terminer): "))
    
if nb_valeurs == 0 : 
    print("Entrez au moins une valeur positive ou nulle !")
else:
    print("Vous avez entré",nb_valeurs,"valeurs.")
    print("La somme vaut",somme,".")
    moyenne = somme/nb_valeurs
    print("La moyenne vaut",moyenne,".")