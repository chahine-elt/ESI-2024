#Script qui tant que la chaîne entrée par l’utilisateur contient un espace,
#le script affiche un message d’erreur et demande un autre mot à l’utilisateur.
mot = input("Entez un mot : ")
while " " in mot :
    print("Erreur")
    mot = input("Entez un mot : ")