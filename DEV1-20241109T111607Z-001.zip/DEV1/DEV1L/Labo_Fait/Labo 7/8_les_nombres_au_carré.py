# Canevas d'un script qui demande un nombre positif n à l’utilisateur et qui affiche tous les
# nombres au carré plus petit ou égal à n.
valeur = -1
while valeur < 0 : 
    valeur = int(input("Entrez un nombre positif : "))
nombre = 1
carre = nombre*nombre
while(carre <= valeur):
    print(carre,"=",nombre,"*",nombre)
    nombre += 1 
    carre = nombre*nombre