from caesar import *

print("Exercice 1 : ")
letter=input("Entrez la lettre : ")
key=int(input("Entrez la clé : "))
while encoder_letter(letter,key) == letter :
    print("Il y a eu une erreur dans la lettre ou la clé.")
    letter=input("Entrez la lettre : ")
    key=int(input("Entrez la clé : "))
print(encoder_letter(letter,key))

'''
print("Exercice 3 : ")
string=input("Entrez la chaine : ")
key=int(input("Entrez la clé : "))
print(encoder_str(string,key))
'''

# print("Exercice 4 : ")
# infile="entree.txt"
# outfile="sortie.txt"
# key=int(input("Entrez la clé : "))
# encode_file(infile,outfile,key)


