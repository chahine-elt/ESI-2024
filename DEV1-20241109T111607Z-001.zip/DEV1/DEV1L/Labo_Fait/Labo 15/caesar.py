#1Chiffrement d’un caractère
def encoder_letter(letter,key):
    return chr((ord(letter)+key-97)%26 + 97)

#3Chiffrement d’une chaîne de caractères
def encoder_str(string,key):
    chiffrer=""
    for i in string:
        if i.isalpha == True:
            i=i.lower()
        chiffrer+=encoder_letter(i,key)
    return chiffrer
    
#5Chiffrement d’un fichier
def encode_file(infile,outfile,key):
    with open(infile) as inf,open(outfile,"w") as outf:
        for ligne in inf:
            outf.write(encoder_str(ligne,key))