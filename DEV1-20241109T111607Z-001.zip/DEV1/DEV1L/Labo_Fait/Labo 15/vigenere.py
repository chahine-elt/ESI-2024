from caesar import *
#7Validité de clés
def valid_str_key(key):
    if type(key) != str:
        return False
    elif len(key) < 2 :
        return False
    else:
        for i in key:
            if ord(i) < 60 or ord(i) > 90:
                return False
        return True
   
def valid_int_key(key):
    verif=0
    if type(key) != tuple:
        return False
    elif len(key) < 2:
        return False
    else:
        for i in key:
            if i == 0:
                verif+=1
            if i < -25 or i > 25 or verif == len(key):
                return False 
        return True
#9Conversion de clés     
def str_to_int_key(key):
    if not valid_str_key(key):
        return None
    else:
        tuple_entier=[]
        for i in key:
            tuple_entier.append(ord(i)-64)
        return tuple(tuple_entier)

def int_to_str_key(key):
    if  not valid_int_key(key):
        return None
    else:
        mot = ""
        for i in key:
            if i != 0:              
                mot+=chr(i+64)
        return mot

#11Chiffrement d'une chaine de caractères    
def encode_str(string,key):
    new_string=""
    cpt=0
    if not valid_int_key(key):
        return None
    else:
        for i in string:
            if cpt == len(key):
                cpt=0
            if i.isalpha():
                new_string+=encoder_letter(i,key[cpt])
                cpt+=1
            else:
                new_string+=i
    return new_string

def encode_file(infile,outfile,key):
    with open(infile) as inf,open(outfile,"w") as outf:
        for ligne in inf:
            outf.write(encode_str(ligne,key))