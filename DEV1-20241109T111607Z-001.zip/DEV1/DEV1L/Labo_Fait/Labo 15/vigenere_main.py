from vigenere import *
'''
#8Test de validité de clés
a=valid_str_key("HELLO")
b=valid_int_key((1, 2, 3, 4))
print(a,b)
a=valid_str_key("HELLo")
b=valid_int_key((0,-25,0,0))
print(a,b)

#10Conversion de clés
print(str_to_int_key("ZELLO"))
print(int_to_str_key((0,25,0,0)))
'''
#12Chiffrement d'une chaine de caractères
string="hell!a"
key=(0, 0, 0, 0)
print(encode_str(string,key))

#13Chiffrement d'un fichier
encode_file("entree.txt","sortie.txt",(1, 2, 3, 4))