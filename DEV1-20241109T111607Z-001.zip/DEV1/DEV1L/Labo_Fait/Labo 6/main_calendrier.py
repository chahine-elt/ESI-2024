import calendrier,textwrap
jour=int(input("Entrez le jour : "))
mois=int(input("Entrez le mois : "))
annee=int(input("Entrez l'année : "))
calendrier.affiche_titre(mois,annee)
calendrier.afficherentete()
texte = " "*calendrier.numero_jour(jour,mois,annee) + calendrier.suite_numeros_jours(mois,annee)
valeur= textwrap.fill(texte,width=20)
print(valeur)