def nom_du_mois(mois):
    liste_mois=[0,"Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Aout","Septembre","Octobre","Novembre","Decembre"]
    return liste_mois[mois]
    
def affiche_titre(mois,annee):
    print("="*20)
    mois = nom_du_mois(mois)
    decalage = len(mois) + 5
    print((20 - decalage)//2*" " + mois,annee)
    print("="*20)
    
def afficherentete():
    print("Lu Ma Me Je Ve Sa Di")
    
def est_bissextiles(annee):
    if ((annee % 4 == 0) and (annee % 100 != 0)) or (annee % 400 == 0):
        return True
    else:
        return False

def suite_numeros_jours(mois,annee):
    if mois == 1:
        return "01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 20 30 31"
    elif mois == 2:
        if est_bissextiles(annee) == True:
            return "01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29"
        else:
            return "01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28"
    elif mois in (3,5,7,8,10,12):
        return "01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 20 30 31"
    elif mois in (4,6,9,11):
        return "01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 20 30"
       
def numero_jour(jour,mois,annee):
    q=jour
    if mois == 1:
        m = 13
    elif mois == 2:
        m = 14
    else : 
        m=mois
    j=annee/100
    k=annee%100
    return 3*int((((q) + ((m+1)*13//5) + (k) + (k//4) + (j//4) + 5*j + 5) % 7))