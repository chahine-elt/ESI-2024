import ligne_caractere
car=input("Entrez le caractere à repeter : ")
n=int(input("Entrez le nombre de fois que le caractere serra repeter :"))
ligne_caractere.affichage(n,car)