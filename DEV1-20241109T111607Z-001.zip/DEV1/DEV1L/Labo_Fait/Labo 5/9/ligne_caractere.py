def affichage(n,car):
    print(car*n)