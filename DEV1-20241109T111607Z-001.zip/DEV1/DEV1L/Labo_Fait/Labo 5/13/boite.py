def affiche_boite(n):
    print("*"*n)
    print("*"," "*(n-4),"*")
    print("*"," "*(n-4),"*")
    print("*"*n)