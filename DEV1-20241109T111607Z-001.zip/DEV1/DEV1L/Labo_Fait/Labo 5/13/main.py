import boite
n=int(input("Entre la taille de la boite : "))
boite.affiche_boite(n)