def est_divisible(a,b):
       return a%b == 0 or b%a == 0 