import divisibilite
a=float(input("Entrer le dividende : "))
b=float(input("Entrer le diviseur : "))
print(divisibilite.est_divisible(a,b))