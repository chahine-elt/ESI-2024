def aire_carre(x):
    return x**2