import carre
x=float(input("Entrez la longueur d'un coté : "))
if x > 0 :
    aire_carre = carre.aire_carre(x)
    print("L'aire du carré vaut :",aire_carre,"cm²")
else:
    print("Erreur le nombre est negatif")