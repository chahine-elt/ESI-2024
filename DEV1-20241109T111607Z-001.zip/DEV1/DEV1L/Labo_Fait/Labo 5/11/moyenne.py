def moyenne(a,b,c):
    la_moyenne = (a+b+c)/3
    return la_moyenne