import moyenne
a=float(input("Entrez le premier nombre : "))
b=float(input("Entrez le deuxieme nombre : "))
c=float(input("Entrez le troisieme nombre : "))
print(moyenne.moyenne(a,b,c))