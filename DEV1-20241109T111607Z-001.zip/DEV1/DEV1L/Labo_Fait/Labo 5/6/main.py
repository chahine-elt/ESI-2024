import carte_aleatoire
print(carte_aleatoire.hasard_carte())