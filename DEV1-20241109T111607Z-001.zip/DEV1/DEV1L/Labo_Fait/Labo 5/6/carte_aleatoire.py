import random
def hasard (a,b):
    return random.randint(a,b)
    
def hasard_carte():
    les_valeurs = [2,3,4,5,6,7,8,9,10,'valet','dame','roi','as']
    les_couleurs = ['pique','trèfle','coeur','carreau' ]
    nb_valeurs = len(les_valeurs)
    nb_couleurs = len(les_couleurs)
    la_valeur = les_valeurs[hasard(0,nb_valeurs-1)] 
    la_couleur = les_couleurs[hasard(0,nb_couleurs-1)] 
    return la_valeur,la_couleur