import adresse_mail
adresse=input("Entrez votre adresse mail : ")
print(adresse_mail.adresse_valide(adresse))