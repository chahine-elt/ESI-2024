def adresse_valide(adresse):
    if (adresse[0] == "@") or (adresse[0] == "@") or (adresse[len(adresse)-1] == "@") or (adresse[len(adresse)-1] == "."):
        return False
    else:
        return "@" in adresse and "." in adresse