import math
def volume_sphere(r):
    return 4/3*math.pi*r**3