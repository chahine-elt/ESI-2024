import couleur
print(couleur.hasard_couleur())