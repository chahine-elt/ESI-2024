import random
def hasard (a,b):
    return random.randint(a,b)
    
def hasard_couleur():
    les_couleurs = ["rouge","vert","jaune","bleu","blanc","noir"]
    nb_couleurs = len(les_couleurs)
    la_couleur = les_couleurs[hasard(0,nb_couleurs-1)] 
    return la_couleur