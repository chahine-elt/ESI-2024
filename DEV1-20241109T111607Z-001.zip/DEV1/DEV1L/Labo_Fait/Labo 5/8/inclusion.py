def contient(texte1,texte2):
       return texte1 in texte2