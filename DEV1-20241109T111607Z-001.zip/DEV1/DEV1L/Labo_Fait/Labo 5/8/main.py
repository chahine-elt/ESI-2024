import inclusion
txt1=input("Entrer le premier texte : ")
txt2=input("Entrer le deuxieme texte : ")
print(inclusion.contient(txt1,txt2))