# Un programme qui donne le type de triangle 
print(" **** Bienvenue ! **** ")
cote1 = float(input("Entrez le premier coté du triangle : "))
cote2 = float(input("Entrez le deuxieme coté du triangle : "))
cote3 = float(input("Entrez le troisieme coté du triangle : "))
if cote1 == cote2 == cote3:
    print("Le triangle est equilaterale")
elif cote1 != cote2 != cote3:
    print("Le triangle est quelconque")
else:
    print("Le triangle est isocèle")