# Un programme qui regarde l'egalité d'un fraction
print(" **** Bienvenue ! **** ")
rep = True
a = float(input("Entrez le premier nombre : "))
b = float(input("Entrez le deuxieme nombre : "))
c = float(input("Entrez le troisieme nombre : "))
d = float(input("Entrez le quatrieme nombre : "))
if b == 0 or d == 0 :
    print("Erreur")
elif a/b == c/d:
    print(rep)
else:
    print(not rep)