# Un programme qui regarde si la premiere lettre d un mot est une voyelle
print(" **** Bienvenue ! **** ")
mot = input("Entrez un mot : ")
voyelle=["a", "e", "i", "o", "u", "y"]
if mot[0] in voyelle:
    print("La premiere lettre est une voyelle")
else:
    print("La premiere lettre n'est pas une voyelle")