# Un programme qui affiche si il y a ou non un ou plusieurs espaces dans un texte
print(" **** Bienvenue ! **** ")
txt = input("Entrez une phrase: ")
espaces = txt.count(' ')
if espaces == 0:
    print("il n'y a pas d'espace")
elif espaces == 1 :
    print("il y a un seul espace")
else:
    print("il y a plus d'un espace")
    