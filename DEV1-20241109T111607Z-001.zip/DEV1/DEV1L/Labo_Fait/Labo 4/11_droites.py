# Un programme qui affiche les coordonnées des points d'intersection
print("Droite ax+by+c=0")
a = int(input("Entrez a : "))
b = int(input("Entrez b : "))
c = int(input("Entrez c : "))
print("ax+by+c")

if a==0 and b==0:
    print("a et b ne peuvent pas être nuls sinon ce n'est plus une droite")
elif a==0 :
    y=-c/b
    print("Droite parallèle à l'axe des x : pas d'intersection avec l'axe des x, y = ", y)
elif b==0 :
    x=-c/a
    print("Droite parallèle à l'axe des y : pas d'intersection avec l'axe des y, x = ", x)
else:
    x=-c/a
    y=-c/b
    print("La droite ax+by+c est : ", a, "*x + ", b, "*y + ", c)
    print("Les coordonnées des points d'intersection sont:")
    print("Intersection avec l'axe des x (y=0) :(", x, ", 0)")
    print("Intersection avec l'axe des y (x=0) :(", y, ", 0)")