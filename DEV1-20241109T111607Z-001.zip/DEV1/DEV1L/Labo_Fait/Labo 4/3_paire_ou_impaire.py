# Un programme qui affiche si un nombre est paire ou impaire
print(" **** Bienvenue ! **** ")
nb = int(input(" Entrez un nombre entier : "))
if nb%2== 0:
    print("Le nombre",nb,"est paire")
else:
    print("Le nombre",nb,"est impair")