# Un programme qui affiche les coordonnées des points d'intersection
import math
a = float(input("Entrez a : "))
b = float(input("Entrez b : "))
c = float(input("Entrez c : "))
print("ax²+bx+c")

delta=(b**2)-4*a*c

if delta > 0 :
    x1=-(b+math.sqrt(delta))/(2*a)
    x2=-(b-math.sqrt(delta))/(2*a)
    print(math.sqrt(delta))
    print("Les racines sont x1=",x1,"et x2=",x2)
elif delta == 0:
    x=-b/2*a
    print("La racine est x=",x)
elif delta < 0 :
    print("Il y a pas de racines")