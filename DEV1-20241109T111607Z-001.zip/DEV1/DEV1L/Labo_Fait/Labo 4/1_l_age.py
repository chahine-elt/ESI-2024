# Un programme qui regarde si la personne est majeur ou non 

print(" **** Bienvenue ! **** ")
age = int(input(" Entrez votre age : "))
if age >= 18:
    print("Vous etes majeur")