#Triangle possible 
bool = True
a = int(input("Entrez la taille du coté AB : "))
b = int(input("Entrez la taille du coté BC : "))
c = int(input("Entrez la taille du coté AC : "))
if a+b > c and b+c > a and c+a > b :
    print("Le triangle peut il être fait :",bool)
else:
    print("Le triangle peut il être fait :",not bool)

