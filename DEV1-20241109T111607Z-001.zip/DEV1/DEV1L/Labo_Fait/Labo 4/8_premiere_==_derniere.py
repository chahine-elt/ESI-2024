# Un programme qui regarde si la premiere lettre et la derniere sont egales ou non 
print(" **** Bienvenue ! **** ")
mot = input("Entrez un mot : ")
if mot[0] == mot[len(mot)-1]:
    print("La première et la dernière lettre sont égales.")
else:
    print("La première et la dernière lettre ne sont pas égales.")