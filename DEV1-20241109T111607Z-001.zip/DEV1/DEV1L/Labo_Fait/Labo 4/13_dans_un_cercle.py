# Dans ou hors du cercle
import math
bool = True
x = int(input("Entrez la coordonnée x : "))
y = int(input("Entrez la coordonnée y : "))
xc = int(input("Entrez le centre xc : "))
yc = int(input("Entrez le centre yc : "))
r = int(input("Entrez le rayon : "))
maxi = math.pow((x-xc), 2) + math.pow((y-yc), 2)
if maxi < math.pow(r, 2):
    print("Le point est dans le cercle :",bool)
elif maxi > math.pow(r, 2):
    print("Le point n'est pas dans le cercle :",not bool)
else :
    print("Le point est sur le cercle")