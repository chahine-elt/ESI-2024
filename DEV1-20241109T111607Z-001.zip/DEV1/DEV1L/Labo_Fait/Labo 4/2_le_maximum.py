# Un programme qui affiche le nombre le plus grand parmis 2 nombres

print(" **** Bienvenue ! **** ")
nb1 = int(input(" Entrez le premier nombre : "))
nb2 = int(input(" Entrez le deuxieme nombre : "))
if nb1 > nb2 :
    print("Le nombre le plus grand est ",nb1)
else:
    print("Le nombre le plus grand est ",nb2)