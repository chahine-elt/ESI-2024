# Un programme calculant le volume du cube dont la
# longueur du côté est entrée au clavier par l'utilisateur
print(" **** Bienvenue ! **** ")
x = int(input("Entrez 3 nombres : "))
y = int(input("Entrez 3 nombres : "))
z = int(input("Entrez 3 nombres : "))
le_minimum = min(x, y, z)
print("Le min de ",x, y, z, " vaut : ", le_minimum)
le_maximum = max(x, y, z)
print("Le min de ",x, y, z, " vaut : ", le_maximum)

