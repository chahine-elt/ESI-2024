# Un programme qui calcule les interet sur plusieurs années

print(" **** Bienvenue ! **** ")
montant = float(input(" Entrez le montant : "))
années = int(input("Entrez le nombre d'années : "))
pourcent = int(input("Entrez le nombre poucentage : "))
sommeInteret = 0
for z in range(années):
    interetAnnées = montant*(pourcent/100)
    sommeInteret += interetAnnées
    montant += interetAnnées

print("le montant avec intérêts sur toutes les années est : ", sommeInteret)