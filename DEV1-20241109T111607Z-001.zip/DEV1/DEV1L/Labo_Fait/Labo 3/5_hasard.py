# Un programme qui tire un nombre au hasard entre deux nombre entrer au clavier
import random
x=int(input("Entrez le premier nombre"))
y=int(input("Entrez le deuxieme nombre"))
print(random.randint(x,y))