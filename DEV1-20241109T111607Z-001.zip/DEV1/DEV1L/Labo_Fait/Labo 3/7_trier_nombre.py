# Un programme qui trie des nombres
l=[]
print("Entrez 4 nombres")
for z in range (4):
    x=float(input())
    l.append(x)
l=sorted(l)
for z in range (len(l)):
    print(l[z],end="")
    if z == (len(l)-1):
        pass
    else:
        print(",",end="")