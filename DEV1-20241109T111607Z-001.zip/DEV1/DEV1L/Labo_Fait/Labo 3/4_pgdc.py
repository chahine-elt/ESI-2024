# Un programme qui affiche les PGDC commun de deux nombre entiers
import math
print(" **** Bienvenue ! **** ")
x=int(input("Entrez 1er nombre : "))
y=int(input("Entrez 2 eme nombres : "))
print(math.gcd(x,y))