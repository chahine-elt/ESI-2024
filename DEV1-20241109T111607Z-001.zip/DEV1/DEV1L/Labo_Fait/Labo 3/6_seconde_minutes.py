# Un programme qui calcul les secondes en minutes
s=int(input("Entrez les secondes : "))
m=s//60
s-=m*60
print(m,'minutes et',s,'secondes')