# Un programme qui calcule les interet sur une année
x=float(input("Entrez le montant : "))
interet=x*1/100
print("L'interet est de : ",interet)