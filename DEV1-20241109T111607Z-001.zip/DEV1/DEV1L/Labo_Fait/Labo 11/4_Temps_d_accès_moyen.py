import time
a_liste=tuple(range(5_000_000))
moyenne_time=0
for i in range (50):
    start_time = time.time()
    value=0
    for j in range (len(a_liste)):
        value += a_liste[j]
    end_time = time.time()
    complet_time = end_time - start_time
    moyenne_time += complet_time
    print(i+1,":",value,complet_time,"s")
moyenne_time= moyenne_time/50
print("Le temps moyen est de",moyenne_time,"s")