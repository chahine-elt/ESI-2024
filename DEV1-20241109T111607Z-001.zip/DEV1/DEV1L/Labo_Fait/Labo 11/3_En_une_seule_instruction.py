a_tuple = (15, 18, 12, 14, 20, 10, 16, 19, 9, 13)
b_tuple = sorted(a_tuple)
print(b_tuple[1:len(b_tuple)-1])