liste_1=[1,2,3,4,5]
liste_2=[6,7,8,9,10]
somme_liste = liste_1 + liste_2
print("liste_1 + liste_2 = ",somme_liste,"\nEt l'id est",id(somme_liste))
liste_1.extend(liste_2)
print("liste_1.extend(liste_2) = ",liste_1,"\nEt l'id est",id(liste_1))
print("La difference est que les id changent")