tuple1=(-4, 12, -71, 33, 20, 32, 96, -22, -7, 70, 82, 62, 11, 72, -36, -16, 84)
def ya_max ():
    return max(tulpe1)
    
print(ya_max())