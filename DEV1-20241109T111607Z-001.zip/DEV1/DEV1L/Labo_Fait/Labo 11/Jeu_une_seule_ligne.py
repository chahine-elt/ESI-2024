import random,os
clearConsole = lambda: os.system('cls' if os.name in ('nt', 'dos') else 'clear')
def add_2_values():
    r1=random.randint(0,19)
    r2=random.randint(0,19)
    while r1==r2 or liste[r1] !=0 or liste[r2] !=0:
        r1=random.randint(0,19)
        r2=random.randint(0,19)
    liste[r1]=random.randint(1,4)
    liste[r2]=random.randint(1,4)

def display():
    print(liste)

def move(position):
    cond=0
    origin=position[0]
    destination=position[1]
    ok = False
    #La Gauche
    if origin > destination and liste[destination] == 0 :
        for i in (1,2,3,4):
            if i in liste[destination:origin]:  
                cond +=1
            if cond == 1:
                return ok 
        if cond == 0:
            liste[destination],liste[origin]=liste[origin],liste[destination]
        
    #La Droite 
    elif origin < destination and liste[destination] == 0:
        for i in (1,2,3,4):
            if i in liste[origin+1:destination]:
                cond +=1
            if cond == 1:
                return ok
        if cond == 0:
            liste[destination],liste[origin]=liste[origin],liste[destination]
    else:
        return ok 

def read():
    origin=int(input("Entrez la case à deplacer : "))
    destination=int(input("Entrez la case où le nombre va être deplacer ira : "))
    return (origin,destination)
    
def remove_3_inline() :
    for i in range(1,len(liste)-1):
        if liste[i-1] == liste[i] == liste[i+1] :
            liste[i-1] = 0
            liste[i] = 0
            liste[i+1] = 0
    
liste=[0]*20
tour=0
condition_fin=True
while condition_fin == True:
    clearConsole()
    if 0 not in liste : 
        print("Vous avez perdu au",tour,"tours !")
        break
    else : 
        tour+=1
        remove_3_inline()
        print("Tour : ",tour)
        add_2_values()
        remove_3_inline()
        print(" 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19")
        display()
        while move(read()) == False :
            print("Vous avez selectionenr un case vide ou la case est occupé ou une case vous bloque")