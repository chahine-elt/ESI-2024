mot=input("Entrez un mot : ")
for i in mot:
    print(i)