n=int(input("Entrez un nombre : "))
print("Nombre pairs : ")
for i in range (1,n+1):
    print(i)

print("Nombre impairs : ")
for i in range (1,n,2):
    print(i)

print("Nombre",-n,"et",n,": ")
for i in range (-n,n+1):
    print(i)