mot=input("Entrez un mot : ")
mot_inverse=mot[::-1]
for i in range (len(mot)):
    if mot[i] == mot_inverse[i]:
        print(mot[i],": est égale à :",mot_inverse[i])
    else:
        print(mot[i],": n'est pas égale à :",mot_inverse[i])
if mot == mot_inverse : 
    print(mot,"est un Palindrome")
else:
    print(mot,"n'est pas un Palindrome")