voyelle=["a", "e", "i", "o", "u", "y","A","E","I","O","U","Y"]
mot=input("Entrez un mot : ")
for i in mot:
    if i in voyelle:
        print(i,"est une voyelle")
    else:
        print(i,"est une consonne")