for i in [1,3,5,7,9]:
    print(i)

for i in [0, 0.25, 0.75, 0.75,1]:
    print(i)
    
for i in ["une","boucle","for"]:
    print(i)