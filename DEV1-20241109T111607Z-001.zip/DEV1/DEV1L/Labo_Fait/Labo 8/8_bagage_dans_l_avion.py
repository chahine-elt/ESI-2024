nombre=int(input("Entrez un nombre entre 1 et 10 : "))
somme_poids=0
while nombre < 1 or nombre > 10:
    nombre=int(input("Entrez un nombre entre 1 et 10 : "))
for i in range (nombre):
    nom=input("Entrez votre nom : ")
    poids=float(input("Entrez le poids de votre votre valise : "))
    if poids > 10:
        print(nom,"vous allez payer un supplément car votre valise dépasse 10Kg (",poids,"Kg).")

    somme_poids+=poids
    
print("Voici le poids totale des valise : ",somme_poids,"Kg")