for i,j in enumerate([76, 23, 18, 6, 5, 2]):
    print(j**(i+1))