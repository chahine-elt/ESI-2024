somme=0
for i in range(1,101):
    somme+=i**2
print(somme)