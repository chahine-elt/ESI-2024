mot=input("Entrez un mot : ")
compteur=0
for i in mot:
    compteur +=1
    print("La lettre",compteur,"est un",i)