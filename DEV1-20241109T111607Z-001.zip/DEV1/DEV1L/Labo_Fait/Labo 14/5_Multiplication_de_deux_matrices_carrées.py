M1=[
    [1,2,3],
    [4,5,6],
    [7,8,9]
]

M2=[
    [9,8,7],
    [6,5,4],
    [3,2,1]
]

if len(M1) != len(M2):
    print("Erreur, les tailles des deux matrices ne sont pas de la même taille")
    
else: 
    M3=[]
    taille=len(M1)
    liste_nombres=[]
    for z in range(taille):
        liste_nombres=[]
        for i in range (taille):
            nombre=0
            for j in range (taille):
                nombre+=M1[z][j]*M2[j][i]
            liste_nombres.append(nombre)
        M3.append(liste_nombres)
    for a in range(len(M1)):
        print(M3[a])