notes=[
        {
        "Matricule":"001",
        "Nom":"Emma",
        "Prénom":"Johnson",
        "Math":18,
        "Progra":15,
        "Phys":16,
        },
        {
        "Matricule":"002",
        "Nom":"Liam",
        "Prénom":"Davis",
        "Math":16,
        "Progra":14,
        "Phys":17,
        },
        {
        "Matricule":"003",
        "Nom":"Olivia",
        "Prénom":"Martin",
        "Math":19,
        "Progra":17,
        "Phys":18,
        },
        {
        "Matricule":"004",
        "Nom":"Noah",
        "Prénom":"Wilson",
        "Math":14,
        "Progra":12,
        "Phys":15,
        },
        {
        "Matricule":"005",
        "Nom":"Ava",
        "Prénom":"Anderson",
        "Math":20,
        "Progra":19,
        "Phys":20,
        },
        {
        "Matricule":"006",
        "Nom":"Lucas",
        "Prénom":"Taylor",
        "Math":17,
        "Progra":16,
        "Phys":19,
        },
        {
        "Matricule":"007",
        "Nom":"Isabella",
        "Prénom":"Parker",
        "Math":13,
        "Progra":11,
        "Phys":14,
        },
        {
        "Matricule":"008",
        "Nom":"Mason",
        "Prénom":"Thomas",
        "Math":15,
        "Progra":13,
        "Phys":16,
        },
        {
        "Matricule":"009",
        "Nom":"Sophia",
        "Prénom":"White",
        "Math":12,
        "Progra":10,
        "Phys":12,
        },
        {
        "Matricule":"010",
        "Nom":"Elijah",
        "Prénom":"Harris",
        "Math":16,
        "Progra":14,
        "Phys":17,
        },
        ]
        
print("Exercices 1 :")
meilleurs_notes=[]

for i in range (len(notes)):
    meilleurs_notes.append([notes[i]["Math"],notes[i]["Matricule"]])
meilleurs_notes.sort(reverse=True)
for i in range (3):
    print(meilleurs_notes[i][1])

moyenne_math=0
moyenne_Progra=0
moyenne_Phys=0
print("\nExercices 2 :")
for i in range (len(notes)):
    moyenne_math += notes[i]["Math"]
    moyenne_Progra += notes[i]["Progra"]
    moyenne_Phys += notes[i]["Phys"]

moyenne_math /= len(notes)
moyenne_Progra /= len(notes)
moyenne_Phys /= len(notes)

print("Math :",moyenne_math)
print("Progra :",moyenne_Progra)
print("Phys :",moyenne_Phys)
    
cpt=0
print("\nExercices 3 :")
for i in range (len(notes)):
    if notes[i]["Math"] > moyenne_math:
        cpt+=1
        print(notes[i]["Nom"])
        print(notes[i]["Prénom"],"\n")

print("Il y a eu",cpt,"élèves qui ont une notes supérieur à la moyenne.")
    