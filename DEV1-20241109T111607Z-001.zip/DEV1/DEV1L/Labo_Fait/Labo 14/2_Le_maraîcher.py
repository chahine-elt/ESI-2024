stock={"potirons":15,"courgettes":20,"poireaux":17,"brocolis":23,"oignons":32}
verif = 0
client=input("Il y a un client (oui ou non) ? \n")
while client != "non":
    verif = 0
    while verif != "non":
        print("J'ai",stock,"en stock.")
        legumes=input("Que voulez vous ? \n")
        print("J'en ai",stock[legumes],"en stock")
        quantites=int(input("Combien en voulez vous ? \n"))
       
        stock[legumes]=stock[legumes]-quantites
        
        if stock[legumes] == 0:
            del stock[legumes]
        verif =input("Voulez vous autres choses (oui ou non) ? \n")
    print("Très bien tenez.")
    client=input("Il y a un client (oui ou non) ? \n")
print("Il reste",stock,".")