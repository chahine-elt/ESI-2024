def add_matrices(M1, M2):
    M3=[[0]*3]*3
    print(M3)
    for i in range (len(M1)):
        M3[i][i]=M1[i][i]+M2[i][i]
    return M3

M1=[[1,2,3],[4,5,6],[7,8,9]]
M2=[[9,8,7],[6,5,4],[3,2,1]]
print(add_matrices(M1, M2))
