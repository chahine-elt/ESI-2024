titre_auteur=[
        {
        "Titre":"Le Secret de l’Éclipse",
        "Auteur":"Sarah Smith",
        "Maison d’Édition":"Librairie Imaginaire",
        "Année":2021
        },
        {
        "Titre":"Les Vents de l’Aventure",
        "Auteur":"David Brown",
        "Maison d’Édition":"Maison d’Édition Enigma",
        "Année":2019
        },
        {
        "Titre":"L’Énigme du Phénix",
        "Auteur":"Laura White",
        "Maison d’Édition":"Éditions Mystérieuses",
        "Année":2020
        },
        {
        "Titre":"Le Château des Ombres",
        "Auteur":"Thomas Black",
        "Maison d’Édition":"Éditions Sombres",
        "Année":2018
        },
        {
        "Titre":"Le Trésor Perdu",
        "Auteur":"Emily Green",
        "Maison d’Édition":"Maison d’Édition Aventure",
        "Année":2021
        },
        {
        "Titre":"Le Mystère de la Forêt",
        "Auteur":"Kevin Turner",
        "Maison d’Édition":"Éditions Enchanteurs",
        "Année":2017
        },
        {
        "Titre":"Les Secrets de la Nuit",
        "Auteur":"Isabelle Davis",
        "Maison d’Édition":"Maison d’Édition Magique",
        "Année":2016
        },
        {
        "Titre":"L’Évasion de l’Île",
        "Auteur":"Emily Green",
        "Maison d’Édition":"Éditions Aventure",
        "Année":2015
        },
        {
        "Titre":"L’Épée de Lumière",
        "Auteur":"Daniel Johnson",
        "Maison d’Édition":"Maison d’Édition Fantastique",
        "Année":2014
        },
        {
        "Titre":"L’Élixir des Rêves",
        "Auteur":"Kevin Turner",
        "Maison d’Édition":"Éditions Imaginaires",
        "Année":2013
        }
        ]

        
print("Exercices 1 :")
for i in range (len(titre_auteur)):
    if titre_auteur[i]["Auteur"] == "Emily Green":
        print(titre_auteur[i]["Titre"])
        
print("\nExercices 2 :")
for i in range (len(titre_auteur)):
    if titre_auteur[i]["Auteur"] == "Kevin Turner":
        print(titre_auteur[i]["Maison d’Édition"])

print("\nExercices 3 :")
for i in range (len(titre_auteur)):
    if titre_auteur[i]["Année"] > 2015:
        print(titre_auteur[i]["Titre"])