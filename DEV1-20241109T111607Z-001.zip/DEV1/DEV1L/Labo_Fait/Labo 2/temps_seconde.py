# Un programme calculant le nombre de secondes  dont l'
# heure , minutes et secondes est entrée au clavier par l'utilisateur

print(" **** Bienvenue ! **** ")
total=0
h = int(input("Entrez le nombre d'heure : "))
m = int(input("Entrez le nombre de minutes : "))
s = int(input("Entrez le nombre de secondes : "))
total+= h*3600
total+=m*60
total+=s
print(total,"secondes")