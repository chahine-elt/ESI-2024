
#exercices 1
print("Exercices 1\n")
age_client = 21
nom_client = 'Charlot'
temperature = 17.5
print(type(age_client))
age_client = [1.2,3]
print(type(age_client),"\n")

#exercices 2
print("Exercices 2\n")
largeur = 2.8
longueur = 34
texte = 'le langage python'
ma_liste= ['A','B','C']

print(longueur * largeur)
print(largeur**3)
print(2*longueur + 2*largeur)
print((longueur + largeur)/2)
print(longueur + largeur/2)
#print(longueur + texte) Erreur car un int et une chaine ne peuvent pas s'additionner
print(longueur - len(texte)) #Ici il n'y a pas d erreur car on soustrait grace a la taille du texte donc un int
print(max(longueur,largeur,len(texte)))
#print(ma_liste*2) Erreur car un int et une liste ne peuvent pas se multiplier
#print(ma_liste+2) Erreur car un int et une liste ne peuvent pas s'additionner
print(texte[0:10]) #Ecrit tout les caracteres de positions 0 à 10
print(texte[0]*10) #Ecrit 10 fois le caractere en position 0 donc l
print(largeur//10,'\n')
#print(texte//10) Erreur car un str ne peut pa se faire diviser

#exercices 3
print("Exercices 3\n")
longueur = (5+3**10)/3
longueur = largeur
5 = longueur
longueur += 5
largeur = largeur/2 - 1
longueur + largeur = texte
texte = texte*5
longueur = texte
longueur = longueur +1
