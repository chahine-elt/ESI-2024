# Un programme calculant le volume du cube dont la
# longueur du côté est entrée au clavier par l'utilisateur

print(" **** Bienvenue ! **** ")
x = int(input("Entrez la valeur du coté du cube : "))
print("L'aire du cube vaut:", x**3)