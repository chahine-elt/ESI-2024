# Un programme calculant l'aire du  dont la
# longueur du côté est entrée au clavier par l'utilisateur

print(" **** Bienvenue ! **** ")
l = int(input("Entrez la valeur de la longueur du rectangle : "))
L = int(input("Entrez la valeur du largeur du rectangle : "))
print("L'aire du rectangle vaut:", l*L)