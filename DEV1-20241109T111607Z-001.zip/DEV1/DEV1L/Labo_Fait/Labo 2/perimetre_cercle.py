import math
# Un programme calculant le périmètre et l'aire du cercle dont le
# rayon du cercle est entrée au clavier par l'utilisateur

print(" **** Bienvenue ! **** ")
r = int(input("Entrez la valeur du côté du rayon : "))
print("Le perimetre du cercle vaut:", math.pi*r*2)
print("L'aire du cercle vaut:", math.pi*r**2)