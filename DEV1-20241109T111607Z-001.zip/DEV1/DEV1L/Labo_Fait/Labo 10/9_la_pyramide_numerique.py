taille=int(input("Entrez la taille de la pyramide numérique : "))
for x in range(1,taille+1):
    ch = " "*(taille-x)
    for y in range(x,1,-1): # Cote gauche du triangle
        ch += str(y)
    for y in range(1,x+1): # Cote droite du triangle
        ch += str(y)
    print(ch)
