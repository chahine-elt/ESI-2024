n=int(input("Entrez la taille du triangle sur pointe : "))
for x in range(n):
    n-=1
    for y in range(n+1):
        print("*",end="")
    print()