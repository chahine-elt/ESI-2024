for x in range(1,13):
    if x in (1,3,5,7,8,10,12):
        nb = 31
    if x in (4,6,9,11):
        nb = 30
    if x == 2:  
        nb=28
    for y in range(1,nb+1):
        print(y,"/",x,"/2023")
    print()