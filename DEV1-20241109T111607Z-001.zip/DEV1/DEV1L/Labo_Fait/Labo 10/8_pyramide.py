taille = int(input("Entrez la taille de la pyramide : "))
for x in range(1,taille+1):
    ligne = " "*(taille-x)
    for y in range(x,x+1):
        ligne += "*"*((2*y)-1)
    print(ligne)