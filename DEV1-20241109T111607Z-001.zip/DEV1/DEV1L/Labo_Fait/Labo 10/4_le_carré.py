n=int(input("Entrez la taille du carré : "))
for x in range (n):
    for y in range(n):
        print("*",end="")
    print()