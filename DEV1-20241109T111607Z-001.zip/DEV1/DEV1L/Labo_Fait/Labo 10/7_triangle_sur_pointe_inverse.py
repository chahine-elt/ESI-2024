n=int(input("Entrez la taille du triangle sur pointe inversé : "))
for x in range (n):
    n-=1
    print(" "*x,end="")
    for y in range(n+1):
        print("*",end="")
    print()