nb_encoder=int(input("Entrez le nombre de nombres que vous voulez encoder : "))
for x in range(nb_encoder):
    premier=True
    nb=int(input("Entrez le nombre que vous voulez encoder : "))
    if nb == 1:
        premier = False
    for i in range(2,nb) :
        if (nb%i) == 0 :
            premier = False
    if premier is True:
        print("Le nombre",nb,"est un nombre premier.")
    else:
        print("Le nombre",nb,"n'est pas un nombre premier.")