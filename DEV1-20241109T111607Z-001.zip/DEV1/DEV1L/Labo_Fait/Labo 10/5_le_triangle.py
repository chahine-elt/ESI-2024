n=int(input("Entrez la taille du triangle : "))
for x in range (1,n+1):
    for y in range(x):
        print("*",end="")
    print()