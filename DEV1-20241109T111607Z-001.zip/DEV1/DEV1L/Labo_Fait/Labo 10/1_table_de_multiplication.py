nb=1
for x in range(1,10):
    nb+=1
    print("La table de : ",nb)
    for y in range(1,11):
        print(y,"x",nb,"=",nb*y)