# Mon premier script Python

# Un programme calculant le volume d'un cube dont la 
# longueur du coté est entrée au clavier par l'utilisateur

print(" **** Bienvenue ! **** ")
x = int(input("Entrez la valeur du côté du cube: "))
print("le volume du cube vaut: ", x**3)
