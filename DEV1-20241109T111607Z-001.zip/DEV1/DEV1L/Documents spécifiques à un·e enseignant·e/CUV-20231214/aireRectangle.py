# Mon premier script Python

# Un programme calculant l'aire du rectangle dont la 
# longueur et la largeur est entrée au clavier par l'utilisateur

print(" **** Bienvenue ! **** ")
longueur = int(input("Entrez la valeur de la longueur du rectangle: "))
largeur = int(input("Entrez la valeur de la largeur du rectangle: "))
print("l'aire du rectangle vaut: ", longueur*largeur)
