# Mon premier script Python

# Un programme calculant le nombre de secondes dans le 
# temps (heures, minutes, secondes) est entrée au clavier par l'utilisateur

print(" **** Bienvenue ! **** ")
h = int(input("Le temps à convertir en secondes - Entrez les heures : "))
m = int(input("Le temps à convertir en secondes - Entrez les minutes : "))
s = int(input("Le temps à convertir en secondes - Entrez les secondes : "))
print("le temps vaut: ", (h*3600)+(m*60)+s, " secondes")
