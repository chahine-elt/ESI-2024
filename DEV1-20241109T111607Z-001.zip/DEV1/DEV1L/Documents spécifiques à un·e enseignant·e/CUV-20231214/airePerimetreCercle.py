# Mon premier script Python

# Un programme calculant l'aire et le périmètre d'un cercle dont la 
# longueur du rayon est entrée au clavier par l'utilisateur

print(" **** Bienvenue ! **** ")
PI=3.14
r = int(input("Entrez la valeur du rayon du cercle: "))
print(r)
print(r**2)
print(PI*r**2)
print("l'aire du cercle vaut: ", PI*r**2)
print("le périmètre du cercle vaut: ", 2*PI*r)
