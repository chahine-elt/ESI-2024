import random

NB_CASES = 20
MIN_VAL = 1
MAX_VAL = 4
plateau = [0]*20

def add_2_values():
    add_1_value()
    add_1_value()

def cherchePosLibre():
    libre = False
    while not libre:
        posAleatoire = random.randint(0, len(plateau) - 1)
        libre = plateau[posAleatoire] == 0
    return posAleatoire

def add_1_value():
    plateau[cherchePosLibre()] = random.randint(MIN_VAL, MAX_VAL)

def display():
    for i in range(len(plateau)):
        print(f"{i:3}", end="")
    
    print()

    for val in plateau:
        if (val == 0):
            print("   ", end="")
        else:
            print(f"{val:3}", end="")

    print()


"""
   vérifier si les cases sont libres
   de orig (exclus) à dest (inclus)
"""
def verifierLibres(orig, dest):
    if orig > dest:
        min = dest
        max = orig - 1
    else:
        min = orig + 1
        max = dest
    for pos in range(min, max + 1):
        if plateau[pos] > 0:
            return False
    return True

def valide(pos):
    return 0 <= pos < len(plateau)


def move(orig, dest):
    if not valide(orig) or not valide(dest):
        print("ERREUR 1")
        return False

    if plateau[orig] == 0 or plateau[dest] != 0:
        print("ERREUR 2")
        return False

    if not verifierLibres(orig, dest):
        print("ERREUR 3")
        return False

    plateau[dest] = plateau[orig]
    plateau[orig] = 0
    return True
    
def lirePosition(msg):
    pos = input(msg)
    while not pos.isdigit() or not valide(int(pos)):
        print("Erreur")
        pos = input(msg)
    return int(pos)

def read():
    orig = lirePosition("Entrez l'origine: ")
    dest = lirePosition("Entrez la destination: ")
    return (orig, dest)
    
def remove_3_inline():
    for pos in range(len(plateau) - 2):
        if plateau[pos] != 0 and plateau[pos] == plateau[pos + 1] == plateau[pos + 2]:
            plateau[pos] = 0
            plateau[pos + 1] = 0
            plateau[pos + 2] = 0

def estFini():
    return nombreDeCasesLibres() < 2

def nombreDeCasesLibres():
    return len([val for val in plateau if val == 0])

def jeu():
    add_2_values()
    while not estFini():
        display()
        orig, dest = read()
        move(orig, dest)
        add_2_values()
        remove_3_inline()
    display()
    print("Le jeu est fini")

jeu()
