#td10 - Écrivez un programme 
# qui affiche toutes les tables de multiplication, 
# de la table 2 à 10

def multiplication():
 print()
 for i in range(2, 11):
  for j in range(2, 11):
   res=j*i
   print(j, "*", i, "=", res)
  print()

