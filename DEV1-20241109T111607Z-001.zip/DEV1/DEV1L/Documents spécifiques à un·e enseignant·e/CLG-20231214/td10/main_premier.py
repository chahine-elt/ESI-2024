#td10 - Écrivez un programme 
# qui demande à l’utilisateur le nombre d’entiers 
# qu’il veut encoder.
# Ensuite, le programme demande à l’utilisateur 
# autant d’entiers 
# et pour chaque entier dit s’il est premier ou non.

import premier

nb_entiers = int(input("Combien d’entiers à encoder : "))


premier.premier_liste(nb_entiers)