#td10 - Écrivez un programme 
# qui demande à l’utilisateur le nombre d’entiers 
# qu’il veut encoder.
# Ensuite, le programme demande à l’utilisateur 
# autant d’entiers 
# et pour chaque entier dit s’il est premier ou non.

# 2, 3, 5, 7, 11, 13, 17, 19, 
# 23, 29, 31, 37, 41, 43, 47, 
# 53, 59, 61, 67, 71, 73, 79, 
# 83, 89, 97

def premier(nb):
 diviseur = 2
 b = False
 while(nb % diviseur != 0 and diviseur < nb):
    diviseur = diviseur + 1
    # print("div = ", diviseur)
 if (diviseur==nb):
  b = True
 return b
 

def premier_liste(nb_entiers):
 print()
 for i in range(0, nb_entiers):
  entier = int(input("Entrez l’entier à encoder : "))
  if premier(entier):
   print("le nombre : ", entier, " est premier")