#td10 - Écrivez un programme 
# qui affiche toutes les tables de multiplication, 
# de la table 2 à 10

import multiplication

multiplication.multiplication()