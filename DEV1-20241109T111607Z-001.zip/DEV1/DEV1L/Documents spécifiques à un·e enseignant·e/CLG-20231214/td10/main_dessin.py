# Écrivez un programme 
# qui demande à l’utilisateur un entier. 
# Le programme affiche ensuite 
# dans la console un carré, 
# de la taille de l’entier choisi,
# en utilisant un caractère devotre choix.

import dessin

nb = int(input("Donnez la longueur du côté du carré : "))

print("-------Le carré-------")
dessin.carré(nb)
print("-------Le triangle-------")
dessin.triangle(nb)
print("-------Le triangle sur pointe-------")
dessin.triangle_pointe(nb)
print("-----Le triangle sur pointe inversé-----")
dessin.triangle_pointe_inverse(nb)
print("-----La pyramide-----")
dessin.pyramide(nb)
print("-----La pyramide numérique-----")
dessin.pyramide_numérique(nb)