#td10 
# Écrivez un programme 
# qui affiche toutes les dates de cette année


import dates
import td6_calendrier


année = int(input("Entrez une année : "))

dates.dates(année)

#mois = 2
#chaine =td6_calendrier.suite_numeros_jours(mois, année)
#print(chaine)
#print(len(chaine))
# 83 28 jours
# 86 29 jours
# 92 31 jours
# 89 30 jours