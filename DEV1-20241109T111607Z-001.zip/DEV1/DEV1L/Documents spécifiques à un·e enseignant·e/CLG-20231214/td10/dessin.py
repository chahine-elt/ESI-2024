# Écrivez un programme 
# qui demande à l’utilisateur un entier. 
# Le programme affiche ensuite 
# dans la console un carré, 
# de la taille de l’entier choisi,
# en utilisant un caractère devotre choix.

def carré(taille):
 for i in range(0, taille):
  for j in range(0, taille):
   print("*", end="")
  print()

# Écrivez un programme 
# qui demande à l’utilisateur un entier. 
# Le programme affiche ensuite dans la console 
# un triangle de la taille de l’entier choisi 
# en utilisant un caractère de votre choix. 

def triangle(taille):
 i=0
 while(i != taille):
  i=i+1
  for j in range(0, i):
   print("*", end="")
  print()


# Écrivez un programme 
# qui demande à l’utilisateur un entier. 
# Le programme affiche ensuite dans la console 
# un triangle sur pointe de la taille de l’entier choisi 
# en utilisant un caractère de votre choix. 

def triangle_pointe(taille):
 i=taille+1
 while(i != 0):
  i=i-1
  for j in range(0, i):
   print("*", end="")
  print()
  
# Écrivez un programme 
# qui demande à l’utilisateur un entier. 
# Le programme affiche ensuite dans la console 
# un triangle sur pointe de la taille de l’entier choisi 
# en utilisant un caractère de votre choix. 
# Le triangle doit être, cette fois-ci, inversé.

def triangle_pointe_inverse(taille):
 i=0
 while(i != taille):
  print(" "*i, end="")
  for j in range(i, taille):
   print("*", end="")
  i=i+1
  print()

# Écrivez un programme qui demande 
# à l’utilisateur un entier. 
# Le programme affiche ensuite dans la console 
# une pyramide de la taille de l’entier choisi, 
# en utilisant un caractère de votre choix.

def pyramide(rows):
 for i in range(0, rows):
  print(" " * (rows - 1 - i), end="")
  print("*" * i, end="")
  print("*", end="")
  print("*" * i)
  
  
# Écrivez un programme qui demande 
# à l’utilisateur un entier. 
# Le programme affiche ensuite dans la console 
# une pyramide numérique de la taille 
# de l’entier choisi, 
# en utilisant un caractère de votre choix.

def pyramide_numérique(rows):
 for i in range(1, rows + 1):
  for j in range(1, rows -i + 1):
   print(end=" ")
  for j in range(i, 0, -1):
   print(j, end="")
  for j in range(2, i+1):
   print(j, end="")
  print()
  
 #autre type de pyramide numérique
 # for i in range(1, rows + 1):
  # print(" "*(rows - i), end="")
  # for j in range(i, 2*i):
   # print(j%10, end="")
  # for j in range(2*i-2, i-1, -1):
   # print(j%10, end="")
  # print()

