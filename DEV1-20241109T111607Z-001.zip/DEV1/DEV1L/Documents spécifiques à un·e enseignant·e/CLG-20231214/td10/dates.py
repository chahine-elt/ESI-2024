#td10
# Écrivez un programme 
# qui affiche toutes les dates de cette année
# 1/1/2023

# 83 28 jours
# 86 29 jours
# 89 30 jours
# 92 31 jours


import td6_calendrier

def dates(année):
 print()
 for mois in range(1, 13):
  chaine =td6_calendrier.suite_numeros_jours(mois, année)
  longueur_chaine=len(chaine)
  if (longueur_chaine==83):
   nbjours_mois=28
  elif (longueur_chaine==86):
   nbjours_mois=29
  if (longueur_chaine==89):
   nbjours_mois=30
  elif (longueur_chaine==92):
   nbjours_mois=31
#  print("*********", nbjours_mois)
  for j in range(1, nbjours_mois + 1):
   print(j, "/", mois, "/", année)
  print()


