# Tuple immuable

t1=(-4, 12, -71, 33, 20, 32, 96, -22)
print(t1)

t2=(-7, 70, 82, 62, 11, 72, -36, -16, 84)
print(t2)

t3 = 2*t1
t4 = t1+t2
print("t3=2*t1 : ", t3)
print("t4 = t1 + t2 : ", t4)
