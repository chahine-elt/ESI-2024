import Exercice2tuples

t=(-4, 12, -71, 33, 20, 32, 96, -22, -7, 70, 82, 62, 11, 72, -36, -16, 84)
print(t)

tempsmoyen=Exercice2tuples.tempsmoyen(t)
print("tempsmoyen = ", tempsmoyen)
sommetuple=Exercice2tuples.sommetuple(t)
print("sommetuple = ", sommetuple)

t2=(-4, 12)
print(t2)
sommetuple=Exercice2tuples.sommetuple(t2)
print("sommetuple = ", sommetuple)


tuple_2 = tuple(range(4999999))
tempsmoyen=Exercice2tuples.tempsmoyen(tuple_2)
sommetuple=Exercice2tuples.sommetuple(tuple_2)
print("tempsmoyen = ", tempsmoyen)
print("sommetuple = ", sommetuple)

# tuple_2 = tuple(range(4999999))
tempsmoyencalculsomme=Exercice2tuples.tempsmoyensommetuple(tuple_2)
print("temps moyen de calcul de la somme : ", tempsmoyencalculsomme)


tempsmoyencalculsomme50fois=Exercice2tuples.tempsmoyensommetuple50fois(tuple_2)
print("temps moyen de calcul de la somme 50 fois : ", tempsmoyencalculsomme50fois)
