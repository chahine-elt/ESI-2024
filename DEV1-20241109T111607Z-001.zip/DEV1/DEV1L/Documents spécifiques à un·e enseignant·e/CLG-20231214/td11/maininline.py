# A TERMINER


# Écrivez un programme 
# écrire la fonction principale qui devrait se résumer à une boucle qui ; 
# affiche, lit les valeurs, déplace, ajoute 2 valeurs, 
# supprime le triplet éventuel.

import inline


# list_1 = inline.add_2_values()
# print(len(list_1))
# inline.display()
# inline.move(3, 14)
# print("*************")
# inline.display()
# inline.add_2_values()
# inline.display()
# print("*********test de read******************")
# t = inline.read()
# print("le tuple : ", t)
# inline.display()
# print("*********remove_3_inline()******************")
# inline.remove_3_inline()
# inline.display()

print("*********La logique du jeu******************")
print("La liste initiale")
inline.display()
print("mettons deux valeurs aléatoires dans cette liste")
inline.add_2_values()
# affiche
inline.display()
print("voici un tour de jeu - il en faudra plusieurs")
print(" avant que les 20 cases ne soient remplies")
# lit les valeurs
t=inline.read()
inline.display()
# déplace
inline.move(t[0], t[1])
inline.display()
# ajoute 2 valeurs
inline.add_2_values()
inline.display()
# supprime le triplet éventuel
inline.remove_3_inline()
inline.display()


print(" ... avant que les 20 cases ne soient remplies ....")
print(" rajouter un while il reste des cases à 0, continuer")

# affiche, 
# lit les valeurs, 
# déplace, 
# ajoute 2 valeurs, 
# supprime le triplet éventuel.


