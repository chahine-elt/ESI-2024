#Exercice 3 tuples

tuple_1 = ('a', 'b', 'c', 'd', 'e')
tuple_3 = tuple_1[2:4]
print(tuple_3)


a_tuple = (15, 18, 12, 14, 20, 10, 16, 19, 9, 13)
print(a_tuple)
print(min(a_tuple))
print(max(a_tuple))
b_tuple = sorted(a_tuple)
print("après le tri")
print(b_tuple)
print(len(b_tuple))

# c_tuple = (b_tuple[1], b_tuple[2], b_tuple[3], b_tuple[4], b_tuple[5], b_tuple[6], b_tuple[7], b_tuple[len(b_tuple)-2])
# print("c_tuple : ", c_tuple)

# print("len(b_tuple) - 1) : ", len(b_tuple) - 1)


# for j in range(1, len(b_tuple) - 1):
 # print("j in range(1, len(b_tuple) - 1) = ", j)

# # d_tuple = b_tuple
# # print(d_tuple)
# # print(len(d_tuple))

# print(len(b_tuple))

# print("plus loin que le tri")
# print(b_tuple)
# print(len(b_tuple))

# for j in range(0, len(b_tuple) - 1):
 # print("j = ", j)


# print("plus loin que le tri")
# print(b_tuple)
# print(len(b_tuple))

# for j in range(1, len(b_tuple) - 1):
 # print("j in range(1, 3) = ", j, " et b_tuple[j]= ", b_tuple[j])
 # d_tuple[j-1]=b_tuple[j]

# print("plus loin que le tri et après l'assignation")
# print(b_tuple)
# print(len(b_tuple))


# print(len(d_tuple))
 
# for j in range(0, len(d_tuple) - 2):
 # print(" d_tuple[j] = ", d_tuple[j] )

# # print(len(d_tuple))
# # print(d_tuple)

# # d_tuple.pop(8)
# # d_tuple.pop(8)

# # print(d_tuple)
# # print(len(d_tuple))


b_tuple.pop(0)
print("après le pop(0) : ")
print(b_tuple)
print(len(b_tuple))

b_tuple.pop(8)
print("après le pop(8) : ")
print(b_tuple)
print(len(b_tuple))

c_tuple = tuple(b_tuple)
print("c_tuple : ")
print(c_tuple)
print(len(c_tuple))

print("au final voici le tuple non trié : ")
a_tuple = (15, 18, 12, 14, 20, 10, 16, 19, 9, 13)
print(a_tuple)
print("et voici le tuple trié sans le premier et sans le dernier : ")
print(c_tuple)

