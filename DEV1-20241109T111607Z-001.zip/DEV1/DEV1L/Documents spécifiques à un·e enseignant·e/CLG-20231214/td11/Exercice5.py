# exercice 5
print("*********************************************************")
list_1 = [1, 2, 3, 4, 5]
print("id of list_1", id(list_1))
print("list_1 = ", list_1)

list_2 = list(range(10))
print("id of list_2", id(list_2))
print("list_2 = ", list_2)

list_1[0] = -1
print("après list_1[0] = -1 : id of list_1", id(list_1))
list_1.append(6) # [-1, 2, 3, 4, 5, 6]
print("après list_1.append(6) : id of list_1", id(list_1))
print("list_1 = ", list_1)
print("*********************************************************")
print()

# list_3 = [7, 8, 9]
# print("list_3 = ", list_3)
# print("id of list_3", id(list_3))

##print("Attention extend ")
##list_1.extend(list_2)
##print("Point d'attention : après list_1.extend(list_2) : id of list_1", id(list_1))
##print(list_1)
##print("Fin de Attention extend ")

##print("*********************************************************")
##print()


# list_1.extend(list_3)
# print("après list_1.extend(list_3) : id of list_1", id(list_1))

print("list_1 = ", list_1) # [-1, 2, 3, 4, 5, 6, 7, 8, 9]
print("list_2 = ", list_2)

print("Attention somme ")
list_somme = list_1 + list_2 
print("Point d'attention : après list_somme = list_1 + list_2 : id of list_somme", id(list_somme))
print("Fin de Attention somme ")

print(list_somme)
