import ListesEx4

l=[-4, 12, -71, 33, 20, 32, 96, -22, -7, 70, 82, 62, 11, 72, -36, -16, 84]
print(l)

tempsmoyen=ListesEx4.tempsmoyen(l)
print("tempsmoyen = ", tempsmoyen)
sommeliste=ListesEx4.sommeliste(l)
print("sommeliste = ", sommeliste)

l2=[-4, 12]
print(l2)
sommeliste=ListesEx4.sommeliste(l2)
print("sommeliste = ", sommeliste)


liste_2 = list(range(4999999))
tempsmoyen=ListesEx4.tempsmoyen(liste_2)
sommeliste=ListesEx4.sommeliste(liste_2)
print("tempsmoyen = ", tempsmoyen)
print("sommeliste = ", sommeliste)

# liste_2 = list(range(4999999))
tempsmoyencalculsomme=ListesEx4.tempsmoyensommeliste(liste_2)
print("temps moyen de calcul de la somme : ", tempsmoyencalculsomme)


tempsmoyencalculsomme50fois=ListesEx4.tempsmoyensommeliste50fois(liste_2)
print("temps moyen de calcul de la somme 50 fois : ", tempsmoyencalculsomme50fois)
