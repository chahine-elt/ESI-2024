#Exercice 3 tuples
#Divers 

tuple_1 = ('a', 'b', 'c', 'd', 'e')
tuple_3 = tuple_1[2:4]
print(tuple_3)


a_tuple = (15, 18, 12, 14, 20, 10, 16, 19, 9, 13)
print(a_tuple)
print(min(a_tuple))
print(max(a_tuple))
b_tuple = sorted(a_tuple)
print("après le tri")
print(b_tuple)
print(len(b_tuple))

c_tuple = (b_tuple[1], b_tuple[2], b_tuple[3], b_tuple[4], b_tuple[5], b_tuple[6], b_tuple[7], b_tuple[len(b_tuple)-2])
print("c_tuple : ", c_tuple)

print("len(b_tuple) - 1) : ", len(b_tuple) - 1)


for j in range(1, len(b_tuple) - 1):
 print("j in range(1, len(b_tuple) - 1) = ", j)

d_tuple = b_tuple
print(d_tuple)
print(len(d_tuple))

print(len(b_tuple))

print("plus loin que le tri")
print(b_tuple)
print(len(b_tuple))

for j in range(0, len(b_tuple) - 1):
 print("j = ", j)
    #e_tuple[j

print("plus loin que le tri")
print(b_tuple)
print(len(b_tuple))

for j in range(1, len(b_tuple) - 1):
 print("j in range(1, 3) = ", j, " et b_tuple[j]= ", b_tuple[j])
 d_tuple[j-1]=b_tuple[j]
 #print("b_tuple[j]= ", b_tuple[j])

print("plus loin que le tri et après l'assignation")
print(b_tuple)
print(len(b_tuple))

print("d_tuple après la boucle for : ", d_tuple)
print("d_tuple après la boucle for : ", d_tuple[0])
print("d_tuple après la boucle for : ", d_tuple[1])
print("d_tuple après la boucle for : ", d_tuple[2])
print("d_tuple après la boucle for : ", d_tuple[3])
print("d_tuple après la boucle for : ", d_tuple[4])
print("d_tuple après la boucle for : ", d_tuple[5])
print("d_tuple après la boucle for : ", d_tuple[6])
print("d_tuple après la boucle for : ", d_tuple[7])
print("d_tuple après la boucle for : ", d_tuple[8])
print("d_tuple après la boucle for : ", d_tuple[9])

print(len(d_tuple))
 
for j in range(0, len(d_tuple) - 2):
 print(" d_tuple[j] = ", d_tuple[j] )

print(len(d_tuple))
print(d_tuple)

d_tuple.pop(8)
d_tuple.pop(8)

print(d_tuple)
print(len(d_tuple))

print(b_tuple)
print(len(b_tuple))


# for j in range(0, len(d_tuple) - 2):
 # e_tuple[j]=0
 # print(" e_tuple[j] = ", e_tuple[j] )


# for j in range(1, len(b_tuple) - 1):
 # d_tuple=b_tuple[j]

# print(d_tuple)

# b_tuple_sansminmax = b_tuple
# print("b_tuple_sansminmax = ", b_tuple_sansminmax)
# for j in range(1, len(b_tuple) - 1):
#  b_tuple_sansminmax[j] = b_tuple[j]
# print("b_tuple_sansminmax après le for : ", b_tuple_sansminmax)