# Écrivez un programme
# Soit le tuple suivant : (-4, 12, -71, 33, 20, 32, 96, -22, -7, 70, 82, 62, 11, 72, -36, -16, 84).
# Écrivez une fonction ya_max qui recherche la valeur maximum de ce tuple.
# Affichez le résultat de votre fonction de recherche de maximum et de la fonction built in
# (max).

# > squares = [i ∗∗ 2 for i in range(1,11)]
# >>> for square in squares :
# ... print(square)

def ya_max(t):
 max = t[0]
 for i in t:
  if i > max :
   max = i
 # print(i)
 #for t in range(0, 17):
 #   print("élément de tuple : ", t)
 print("max : ", max)
 print("la longueur du tuple est : ", len(t))
 print()
 
 
def autre_max(t):
 maximum = max(t)
 return maximum
