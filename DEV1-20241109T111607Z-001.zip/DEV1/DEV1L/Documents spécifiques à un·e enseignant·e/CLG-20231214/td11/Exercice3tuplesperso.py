#Exercice 3 tuples

tuple_1 = ('a', 'b', 'c', 'd', 'e')
tuple_3 = tuple_1[2:4]
print(tuple_3)


a_tuple = (15, 18, 12, 14, 20, 10, 16, 19, 9, 13)
print(a_tuple)
print(min(a_tuple))
print(max(a_tuple))
b_tuple = sorted(a_tuple)
print(b_tuple)
b_tuple_sansminmax = b_tuple
print("b_tuple_sansminmax = ", b_tuple_sansminmax)
for j in range(1, len(b_tuple) - 1):
 b_tuple_sansminmax[j] = b_tuple[j]
print("b_tuple_sansminmax après le for : ", b_tuple_sansminmax)