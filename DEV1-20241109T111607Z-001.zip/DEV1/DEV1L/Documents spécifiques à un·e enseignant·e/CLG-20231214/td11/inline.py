# A TERMINER

# in line

import random

# 1. créez une liste de 
# 20 éléments initialisés à 0;
list_1=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

# 2. écrivez une fonction add_2_values() 
# qui ajoute deux valeurs à une place aléatoire
# et de valeur aléatoire 
#(pas spécialement différentes) 
# comprises entre 1 et 4 ;
def add_2_values():
 pos1 = random.randint(0, 19)
 pos2 = random.randint(0, 19)
 val1 = random.randint(1, 4)
 val2 = random.randint(1, 4)
 list_1.insert(pos1, val1)
 list_1.insert(pos2, val2)
 # print("pos1 = ", pos1)
 # print("pos2 = ", pos2)
 # print("val1 = ", val1)
 # print("val2 = ", val2)
 #display()
 return list_1
 
# 3. écrivez une fonction display() 
# qui affiche cette liste ;
def display():
 print(list_1)

# 4. écrivez une fonction move(origin, destination) 
# qui déplace la valeur de la position d’origine 
# vers la position de destination. 
# Attention, les cases entre les deux et la
# destination doivent être libres ;
# Les cases ENTRE LES DEUX doivent être libres   
def move(origin, destination):
 for i in range(0, list_1[len(list_1)-1]):
  if list_1[i]==0:
   list_1[destination]=list_1[origin]
   list_1[origin]=0
 

# 5. écrivez une fonction read() qui 
# lit les deux valeurs (entrées au clavier). 
# Cette fonction peut retourner un tuple 
# et doit être un peu robuste ;
def read():
 origine = int(input("Entrez une valeur origine entre 0 et 19 inclus : "))
 destination = int(input("Entrez une valeur destination entre 0 et 19 inclus : "))
 t = (origine, destination)
 return t

# 6. écrivez une fonction remove_3_inline() 
# qui cherche s’il y a 3 valeurs identiques et
# consécutives et qui les supprime s’il échet ;
# def remove_3_inline():
def remove_3_inline():
 for i in range(0, list_1[len(list_1)-1]):
  if ((i+2)<=len(list_1)-1 
   and list_1[i]==list_1[i+1] 
   and list_1[i+1]==list_1[i+2]):
   del list_1[i:i+1:i+2]
