# Exercice 4

import time

list_1 = [1, 2, 3, 4, 5]
list_2 = list(range(10_000_000))

print(list_1)
# print(list_2)

def tempsmoyen(a_liste):
 start_time = time.time()
 for j in range(len(a_liste)):
  value = a_liste[j]
 end_time = time.time()
 tempsmoyen = end_time - start_time
 return(tempsmoyen)


def sommetuple(a_liste):
 sum = 0
 for j in range(len(a_liste)):
  sum+=a_liste[j]
 return(sum)
 
def tempsmoyensommetuple(a_liste):
  start_time = time.time()
  sum = 0
  for j in range(len(a_liste)):
   sum+=a_liste[j]
  end_time = time.time()
  tempsmoyen = end_time - start_time
  return(tempsmoyen)


def tempsmoyensommetuple50fois(a_liste):
  sumtempsmoyen=0
  moyennetempsmoyen=0
  compteur=0
  for i in range(50):
   compteur+=1
   start_time = time.time()
   sum = 0
   for j in range(len(a_liste)):
    sum+=a_liste[j]
   end_time = time.time()
   tempsmoyen = end_time - start_time
#   print("temps moyen : ", tempsmoyen)
   sumtempsmoyen += tempsmoyen
#   print("sumtempsmoyen : ", sumtempsmoyen)
#  print("compteur = ", compteur)
  moyennetempsmoyen = sumtempsmoyen/compteur
  return(moyennetempsmoyen)
