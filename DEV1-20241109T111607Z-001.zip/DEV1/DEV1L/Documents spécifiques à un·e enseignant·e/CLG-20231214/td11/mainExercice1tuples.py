import Exercice1tuples

t=(-4, 12, -71, 33, 20, 32, 96, -22, -7, 70, 82, 62, 11, 72, -36, -16, 84)
print(t)
#print(t[0])
#print(t[1])
Exercice1tuples.ya_max(t)


maximum = Exercice1tuples.autre_max(t)
print("le max built-in avec l'appel à la fonction de Python : ", maximum)

