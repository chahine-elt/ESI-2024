# Écrivez un programme 
# qui demande à l’utilisateur un mot. 
# Pour chaque lettre de ce mot,
# le programme dit 
# s’il s’agit d’une voyelle ou d’une consonne.

mot = input("Entrez mot : ")
mot_petit = mot.lower()
print("mot petit : ", mot_petit)

print("façon avec enumerate")
for position, lettre in enumerate(mot_petit):
# print("la lettre ", i+1, " est un ", j)
 if (lettre in ('aeiouy')):
  print(lettre, " est une voyelle")
 else:
  print(lettre, " est une consonne")


print("autre façon avec range")
for indice in range(len(mot_petit)):
 if (mot_petit[indice] in ('aeiouy')):
  print(mot[indice], " est une voyelle")
 else:
  print(mot[indice], " est une consonne")
 