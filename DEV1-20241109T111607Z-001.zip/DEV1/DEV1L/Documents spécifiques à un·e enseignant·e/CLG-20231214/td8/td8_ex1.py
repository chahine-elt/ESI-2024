#TD8 exercice 1
# affiche les entiers impairs de 1 à 9.
# affiche les nombres 0, 0.25, 0.5, 0.75 et 1.
# affiche les mots "une", "boucle", "for".

for i in range(0, 100):
 print(i)
 
for i in range(10):
 print(i)
 
print("====nombres de 1 à 9====")
for i in range(1, 10):
 if i%2==1:
  print(i)

# affiche les nombres 0, 0.25, 0.5, 0.75 et 1
print("====affiche les nombres 0, 0.25, 0.5, 0.75 et 1===")
for i in [0, 0.25, 0.5, 0.75]:
 print(i)
 
 
# affiche les mots "une", "boucle", "for".
print("====affiche les mots une, boucle et for")
for i in ['une', 'boucle', 'for']:
 print(i)
 

for i in range(0, 10, 3):
 print(i)
