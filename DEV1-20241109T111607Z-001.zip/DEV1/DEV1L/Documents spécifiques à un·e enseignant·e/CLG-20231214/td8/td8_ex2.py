#TD8 exercice 2
# afficher tous les nombres entiers entre 1 et n.
# afficher tous les nombres impairs entre 1 et n. N’utilisez pas d’alternative.
# afficher tous les nombres entre -n et n.

nb = int(input("Entrez un nombre entier : "))

# afficher tous les nombres entiers entre 1 et n.
# while(compteur <= nb):
        # print(compteur)
    # compteur = compteur + 1
for i in range(1, nb+1):
 print(i)


# afficher tous les nombres impairs entre 1 et n. 
# N’utilisez pas d’alternative.
# nombres impairs
# while(compteur <= nb):
    # if (compteur%2==1):
        # print(compteur)
    # compteur = compteur + 1
print("afficher tous les nombres impairs entre 1 et n.")
for i in range(1, nb+1):
 if (i%2==1):
  print(i)

print("sans alternative : tous les nombres impairs.")
for i in range(1, nb+1, 2):
  print(i)
  
# afficher tous les nombres entre -n et n.
# compteur = -1*nb
# while(compteur <= nb):
 # print(compteur)
 # compteur = compteur + 1
print("afficher tous les nombres entre -n et n.")
for i in range(-nb, nb+1):
  print(i)
