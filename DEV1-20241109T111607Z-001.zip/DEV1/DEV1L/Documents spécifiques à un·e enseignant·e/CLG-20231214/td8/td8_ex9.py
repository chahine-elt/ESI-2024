# Un palindrome est un mot 
# qui peut aussi bien se lire de gauche à droite que de droite
# à gauche. Comme le mot "kayak" par exemple. 
# Écrivez un programme qui demande à
# l’utilisateur un mot. 
# Le programme doit dire 
# si la première lettre est la même que la
# dernière, si la deuxième est la même que l’avant-dernière et ainsi de suite. 
# A la fin, le programme doit alors dire 
# si le mot est un palindrome ou non.
# Astuce : soit une variable txt contient du texte, vous pouvez inverser ce texte en effectuant
# la commande txtInverse = txt[::-1].

mot = input("Entrez un mot : ")
mot_petit = mot.lower()
print("mot_petit = ", mot_petit)
mot_inverse = mot[::-1]

print("===================")
print("mot")
for indice in range(len(mot_petit)):
 print(mot[indice])

print("===================")
print("mot inversé")
for indice in range(len(mot_petit)):
 print(mot_inverse[indice])

print("===================")
ind = 0
while (ind<=len(mot)-1 and mot[ind]==mot_inverse[ind]):
 ind=ind+1
print("indice = ", ind)
print("len(mot) = ", len(mot))
print("===================")
if (ind==len(mot)):
 print("Le mot est bien un palindrome")
else:
 print("Le mot n\'est PAS un palindrome")
print("===================")
print("Fin du programme")

