#TD8 exercice 3
# Modifier le script pour qu’il demande à l’utilisateur un mot. Le script doit afficher chaque
# lettre de ce mot.


mot = input("Entrez mot : ")

for i in mot:
 print(i)