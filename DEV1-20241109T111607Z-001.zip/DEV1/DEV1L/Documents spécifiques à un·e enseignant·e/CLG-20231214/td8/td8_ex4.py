# TD8 exercice 4
# Écrivez un programme qui demande à l’utilisateur un mot. Pour toutes les lettres dans
# ce mot le programme affiche la place de la lettre dans le mot ainsi que cette lettre..


mot = input("Entrez mot : ")


for i, j in enumerate(mot):
 print("la lettre ", i+1, " est un ", j)
