# Écrivez un programme qui fait 
# la somme des carrés des 100 premiers entiers.

import math

somme=0
for i in range(1,101):
 somme+=math.pow(i, 2)

print("la somme des carrés" 
" des 100 premiers entiers est : ", somme)