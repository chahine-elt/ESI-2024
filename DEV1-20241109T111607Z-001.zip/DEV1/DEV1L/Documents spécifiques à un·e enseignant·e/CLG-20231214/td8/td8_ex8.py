# Écrivez un programme qui demande à l’utilisateur 
# un nombre entier entre 1 et 10. 
# Ce nombre représente le nombre de passagers 
# dans un avion. 
# Pour chaque personne, le
# programme demande leur nom. 

# Le programme demande alors pour chaque passager 
# le poids de sa valise. 
# Pour chaque personne qui a une valise 
# d’un poids supérieur à 10 kg, 
# le programme affiche le nom de la personne 
# et lui signale qu’il devra payer un supplément.
# Le programme calcule finalement 
# le poids total de toutes les valises et l’affiche.


nb = int(input("Entrez un nombre entier entre 1 et 10 : "))
somme_poids=0

for indice in range(nb):
 nom = input("Entrez votre nom : ")
 poids = int(input("Entrez le poids de votre valise : "))
 if (poids>10):
    print("Mr/Me ", nom, " Vous devrez payer un supplément")
 somme_poids+=poids
print("Le poids de toutes les valises est :", somme_poids)
 