# Pour chaque nombre de la liste [76, 23, 18, 6, 5, 2] calculer et affiche ce nombre à la
# puissance égale à sa place dans la liste. Par exemple, pour le premier nombre, il faut
# calculer 76^1, pour le deuxième, il faut calculer 23^2
# et ainsi de suite

import math

liste = [76, 23, 18, 6, 5, 2]

print(liste)
for i, j in enumerate(liste):
 print("position : ", i+1, " nb^puissance ", math.pow(j, i+1))