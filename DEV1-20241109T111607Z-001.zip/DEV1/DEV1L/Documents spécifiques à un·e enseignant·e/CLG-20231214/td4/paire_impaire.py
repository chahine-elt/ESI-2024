# Un programme paire/impaire

x = int(input("Entrez une valeur: "))

if x%2==0:
 print(x, " est paire")
else:
 print(x, " est impaire")