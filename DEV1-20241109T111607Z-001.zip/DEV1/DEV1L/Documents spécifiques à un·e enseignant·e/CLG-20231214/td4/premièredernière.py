# première dernière

mot = input("Entrez un mot : ")

if mot[0]==mot[len(mot)-1] :
 print("première et dernière lettre identiques")
else:
 print("première et dernière lettre différentes")