# voyelle

mot = input("Entrez un mot : ")

mot2=mot.lower();

if mot2[0]=='a' or mot2[0]=='e' or mot2[0]=='i' or mot2[0]=='o' or mot2[0]=='u' :
 print("la première lettre est une voyelle")
else:
 print("la première lettre est une consonne")