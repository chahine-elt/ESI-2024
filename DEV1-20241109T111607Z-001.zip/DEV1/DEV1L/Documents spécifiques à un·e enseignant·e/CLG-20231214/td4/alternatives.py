# Un programme alternatives

x = int(input("Entrez une valeur: "))

if x > 0:
 print("Ce nombre est positif")
elif x < 0:
 print("Ce nombre est négatif")
else:
 print("Ce nombre est nul")