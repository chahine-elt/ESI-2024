# Un programme alternatives

x = int(input("Entrez votre age: "))

if x >= 18:
 print("vous êtes majeur")
#else:
# print("vous êtes mineur")