# td6

def nom_du_mois(mois):
 if (mois==1):
  nom = 'Janvier'
 elif (mois==2):
  nom = 'Février'
 elif (mois==3):
  nom = 'Mars'
 elif (mois==4):
  nom = 'Avril'
 elif (mois==5):
  nom = 'Mai'
 elif (mois==6):
  nom = 'Juin'
 elif (mois==7):
  nom = 'Juillet'
 elif (mois==8):
  nom = 'Aout'
 elif (mois==9):
  nom = 'Septembre'
 elif (mois==10):
  nom = 'Octobre'
 elif (mois==11):
  nom = 'Novembre'
 elif (mois==12):
  nom = 'Décembre'
 return nom

def afficher_titre(mois, annee):
    print("========================")
    print("      ", nom_du_mois(mois), annee, "       ")
    print("========================")   

def afficherEntête():
 print("Lu Ma Me Je Ve Sa Di")

# si elle est divisible par 4 et non divisible par 100, ou ;
# si elle est divisible par 400.
def est_bissextile(annee):
 bool = False
 if ((annee%4==0 and annee%100!=0) or (annee%400==0)):
  bool = True
 return bool

def suite_numeros_jours(mois,annee):
 if (mois==1 or mois==3 or mois==5 or mois==7 or mois==8 or mois==10 or mois==12):
  dates = "01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31"
 elif (mois==4 or mois==6 or mois==9 or mois==11):
  dates = "01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30"
 elif ((mois==2) and (est_bissextile(annee))):
  dates = "01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29"
 elif ((mois==2) and (not(est_bissextile(annee)))):
  dates = "01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28"
 return dates

def numero_jour(jour,mois, année):
 q=jour
 K=année%100
 J=année/100
 if (mois==1):
  mois = 13
 elif (mois==2):
  mois=14
 premier_jour_du_mois = (int)((q 
                        + (int)(((mois+1)*13)/5) 
                        + K + (int)(K/4) 
                        + (int)(J/4) + 5*J + 5)%7)
 return premier_jour_du_mois