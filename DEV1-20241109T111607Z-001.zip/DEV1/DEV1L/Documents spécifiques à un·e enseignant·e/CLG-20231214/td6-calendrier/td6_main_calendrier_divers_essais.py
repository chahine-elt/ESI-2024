# td6 finir l'affichage du calendrier

import td6_calendrier
import textwrap
print('*****************************')
mois = int(input("Entrez un mois : "))
année = int(input("Entrez une année : "))
jour = int(input("Entrez un jour : "))

td6_calendrier.afficher_titre(mois, année)
td6_calendrier.afficherEntête()

décalage = td6_calendrier.numero_jour(jour,mois, année)
print(" décalage = ", décalage)
#nb_décalage2="   "*décalage
nb_décalage2=3*décalage
strs=td6_calendrier.suite_numeros_jours(mois,année)
print(""*nb_décalage2 + td6_calendrier.suite_numeros_jours(mois,année))
print('*****************************')
print('*****************************')

strs = " "*nb_décalage2 + strs 

print('Début Affichage du calendrier---------')
print(strs)
#print(nb_décalage2 + textwrap.fill(strs, 20))
print(textwrap.fill(strs, 20))
print('Fin Affichage du calendrier---------')


#strs=td6_calendrier.suite_numeros_jours(mois,année)
#print(" "*nb_décalage, textwrap.fill(strs, 20-nb_décalage))


print('*****************************')
print('*****************************')



nb_décalage = 3*décalage -1
print("décalage=", décalage)
print("nb_décalage=", nb_décalage)
print(" "*nb_décalage, td6_calendrier.suite_numeros_jours(mois,année))
print("--------------------------------")
print(td6_calendrier.suite_numeros_jours(mois,année))

print(type(td6_calendrier.suite_numeros_jours(mois,année)))
strs=td6_calendrier.suite_numeros_jours(mois,année)
#nb_décalage=4
print(" "*nb_décalage, textwrap.fill(strs, 20-nb_décalage))
print("--------------------------------")

#td6_calendrier.suite_numeros_jours(mois,année)

jour_demandé = td6_calendrier.numero_jour(jour,mois, année)
print("jour demandé : ", jour_demandé)

strs2 = "In my project, I have a bunch of strings that are read in from a file. Most of them, when printed in the command console, exceed 80 characters in length and wrap around, looking ugly."
print(textwrap.fill(strs2, 20))

# value = """This function returns the answer as STRING and not LIST."""
# string = textwrap.fill(text=value) 
  
# print (string)

#année 2008 mois mars=3
#3 mars c'est lundi ->0
#4 mars c'est mardi ->1
#5 mars c'est mercredi ->2
#6 mars c'est jeudi ->3
#7 mars c'est vendredi ->4
#8 mars c'est samedi ->5
#9 mars c'est dimanche ->6

#1 mars c'est samedi->5
#2 mars c'est dimanche->6

#10 mars c'est lundi->0
#11 mars c'est mardi->1
#12 mars c'est mercredi->2
#13 mars c'est jeudi->3
#14 mars c'est vendredi->4
#15 mars c'est samedi->5
#16 mars c'est dimanche->6

#17 mars c'est lundi->0



#print(td6_calendrier.est_bissextile(année))