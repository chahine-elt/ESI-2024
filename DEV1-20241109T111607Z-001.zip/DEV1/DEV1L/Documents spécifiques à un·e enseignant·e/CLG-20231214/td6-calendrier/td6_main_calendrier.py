# td6
import td6_calendrier
import textwrap

print('**********Programme Calendrier*******************')
mois = int(input("Entrez un mois : "))
année = int(input("Entrez une année : "))
jour = int(input("Entrez un jour : "))

td6_calendrier.afficher_titre(mois, année)
td6_calendrier.afficherEntête()

décalage = td6_calendrier.numero_jour(jour,mois, année)
# print(" décalage = ", décalage)
nb_décalage2=3*décalage
strs=td6_calendrier.suite_numeros_jours(mois,année)
#print(""*nb_décalage2 + td6_calendrier.suite_numeros_jours(mois,année))
strs = " "*nb_décalage2 + strs 
#print('Début Affichage du calendrier---------')
print(textwrap.fill(strs, 20))
#print('Fin Affichage du calendrier---------')
print('**********Programme Calendrier*******************')
print("décalage = ", décalage)


#année 2008 mois mars=3
#3 mars c'est lundi ->0
#4 mars c'est mardi ->1
#5 mars c'est mercredi ->2
#6 mars c'est jeudi ->3
#7 mars c'est vendredi ->4
#8 mars c'est samedi ->5
#9 mars c'est dimanche ->6

#1 mars c'est samedi->5
#2 mars c'est dimanche->6

#10 mars c'est lundi->0
#11 mars c'est mardi->1
#12 mars c'est mercredi->2
#13 mars c'est jeudi->3
#14 mars c'est vendredi->4
#15 mars c'est samedi->5
#16 mars c'est dimanche->6

#17 mars c'est lundi->0



#print(td6_calendrier.est_bissextile(année))