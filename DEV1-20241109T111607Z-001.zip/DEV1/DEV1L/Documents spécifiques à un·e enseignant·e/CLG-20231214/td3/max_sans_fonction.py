# Un programme max

x = int(input("Entrez une valeur: "))
y = int(input("Entrez une autre valeur: "))
#max = x

#if y > max:
if y>x:
 print("le max est : ", y)
else:
 print("le max est : ", x)
 