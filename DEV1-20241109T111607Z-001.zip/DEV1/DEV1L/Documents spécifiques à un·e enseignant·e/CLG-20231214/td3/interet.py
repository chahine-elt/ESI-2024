# Un programme intérêts
# 1*montant + 2%*montant = montant*(1+2%)=montant*(1+0.02)=montant*1.02

print(" **** Bienvenue ! **** ")
m = float(input(" Entrez le montant : "))
interet = m*0.02
print("le montant avec intérêts est : ", interet)


