# Un programme qui calcule la racine carrée d'un nombre entré au clavier
# Attention: le programme plante si le nombre entré est négatif

import math

print(" **** Bienvenue ! **** ")
x = int(input(" Entrez un nombre positif : "))
print("La racine carrée de",x,"vaut", math.sqrt(x))