# Un programme min et max

import math

print(" **** Bienvenue ! **** ")
x = int(input(" Entrez un nombre : "))
y = int(input(" Entrez un nombre : "))
z = int(input(" Entrez un nombre : "))
le_minimum = min(x, y, z)
print("Le min de ",x, y, z, " vaut : ", le_minimum)
le_maximum = max(x, y, z)
print("Le min de ",x, y, z, " vaut : ", le_maximum)