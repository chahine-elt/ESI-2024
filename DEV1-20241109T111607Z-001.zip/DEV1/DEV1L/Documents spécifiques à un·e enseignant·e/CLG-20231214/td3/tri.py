# Un programme tri


print(" **** Bienvenue ! **** ")
x = float(input(" Entrez un nombre : "))
y = float(input(" Entrez un nombre : "))
z = float(input(" Entrez un nombre : "))
l = [x, y, z]
tri = sorted(l)
print(tri)
print(tri[0])
print(tri[1])
print(tri[2])
