# Un programme secondes en minutes


print(" **** Bienvenue ! **** ")
s = int(input(" Entrez les secondes : "))
minutes = s//60;
secondes = s%60;
print("le nombre de minutes est : ", minutes)
print("le nombre de secondes est : ", secondes)