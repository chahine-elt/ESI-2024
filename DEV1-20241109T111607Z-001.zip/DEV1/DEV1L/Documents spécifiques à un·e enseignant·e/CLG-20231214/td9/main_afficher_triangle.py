# TD9-Bilan
import afficher_triangle


nb_lignes = int(input("Entrez le nb_lignes : "))


while(nb_lignes < 3 or nb_lignes > 10 ):
 nb_lignes = int(input("Entrez le nb_lignes," 
 "il doit être entre 3 et 10 ! : "))

afficher_triangle.afficher_triangle(nb_lignes)
