# TD9-Bilan
import math


def total_payer(prix_unitaire, quantité_article):
 total=0
 while(prix_unitaire != -1 ):
  print("prix_unitaire : ", prix_unitaire)
  print("quantité_article : ", quantité_article)
  total = total + prix_unitaire*quantité_article
  print("total en cours : ", total)
  prix_unitaire = int(input("Entrez le prix à l'unité,"
  "-1 pour STOP : "))
  if (prix_unitaire !=-1 ):
   quantité_article = int(input("Entrez le nombre d'articles : "))
  else:
   print("prix_unitaire : ", prix_unitaire)
 print("Le total des achats est de : ", total)

