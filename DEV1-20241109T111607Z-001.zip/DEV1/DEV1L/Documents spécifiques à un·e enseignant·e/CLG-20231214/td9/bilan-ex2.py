# TD9-Bilan
import math

poids = int(input("Entrez votre poids : "))
taille = float(input("Entrez votre taille : "))

IMC=poids/(math.pow(taille, 2))


print("l'IMC vaut : ", IMC)

