# TD9-Bilan
import total_payer


prix_unitaire = int(input("Entrez le prix à l'unité,"
"-1 pour STOP :" ))
quantité_article=0
if (prix_unitaire != -1):
 quantité_article = int(input("Entrez le nombre d'articles : "))

total_payer.total_payer(prix_unitaire, quantité_article)