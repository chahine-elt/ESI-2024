# TD9-Bilan
import math

nb = float(input("Entrez un nombre réel : "))

print("valeur ceil : ", math.ceil(nb))
print("valeur floor : ", math.floor(nb))
