# TD9-Bilan
import math

def afficher_triangle(n):
 for i in range(1, n+1):
  print('x'*i)
