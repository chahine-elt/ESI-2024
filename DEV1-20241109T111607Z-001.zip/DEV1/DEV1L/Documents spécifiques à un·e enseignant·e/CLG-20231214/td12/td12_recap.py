# Recap TD12

# Exercice 7 Moyenne
# Écrivez une fonction moyenne(ma_liste) 
# qui reçoit en paramètre une liste de nombres flottants 
# et retourne la valeur moyenne des éléments de la liste.
def moyenne(ma_liste):
 sum = 0
 for i in range(len(ma_liste)) :
  sum += ma_liste[i]
 moyenne = 1.0*sum/len(ma_liste)
 return moyenne

ma_liste=[1.0, 2.0, 3, 4, 5, 6.5, 7.5]
print(ma_liste)
moyenne = moyenne(ma_liste)
print("moyenne = ", moyenne)

# Exercice 8 Liste des éléments communs
# Écrivez une fonction liste_elements_communs(l1, l2) 
# qui reçoit deux listes d’entiers en paramètre 
# et retourne la liste des éléments communs aux deux listes. 
# Veillez à ce que les éléments de la liste retournée 
# soient deux à deux distincts.
def liste_elements_communs(l1, l2):
 liste_elements_communs = []
 for i in range(len(l1)):
  for j in range(len(l2)):
   if l1[i]==l2[j]:
    liste_elements_communs.append(l1[i])
 return liste_elements_communs

l1 = [1, 2, 3, 4, 5, 10, 100]
l2 = [100, 101, 2, 5, 4]
print("l1 = ", l1)

print("l2 = ", l2)
liste_elements_communs = liste_elements_communs(l1, l2)
print("liste_elements_communs = ", liste_elements_communs)

# Exercice 9 Le nettoyage
# Écrivez une fonction suppression_occurrences(ma_liste, mot) 
# qui reçoit une liste de chaines de caractères 
# et un mot(chaine de caractères) en paramètre 
# et supprime de cette liste
# toutes les occurrences de mot. 
# Votre fonction retournera le nombre de 
# suppressions effectuées.
def suppression_occurrences(ma_liste, mot):
 cpt=0
 for i in range(len(ma_liste)):
   if mot in ma_liste:
    ma_liste.remove(mot)
    cpt+=1
 return ma_liste

def suppression_occurrences2(ma_liste, mot):
 cpt=0
 for i in range(len(ma_liste)):
   if mot in ma_liste:
    ma_liste.remove(mot)
    cpt+=1
 return cpt

ma_liste = ["bonjour", "lundi", "novembre", "esi", "bonjour", "lundi"]
mot = "bonjour"
print("ma_liste = ", ma_liste)
print("mot = ", mot)
nouvelle_liste = suppression_occurrences(ma_liste, mot)
print("nouvelle_liste = ", nouvelle_liste)

ma_liste = ["bonjour", "lundi", "novembre", "esi", "bonjour", "lundi"]
mot = "bonjour"
print("ma_liste = ", ma_liste)
print("mot = ", mot)
cpt = suppression_occurrences2(ma_liste, mot)
print("compteur = ", cpt)


# Exercice 10 Suppression des doublons
# Écrivez une fonction suppression_doublons(ma_liste) 
# qui reçoit en paramètre une liste
# d’entiers avec de possibles doublons 
# et qui supprime les doublons consécutifs de la liste.
# Exemple : Si la liste est [7, 3, 3, 8, 8, 8, 7], 
# le résultat est [7, 3, 8, 7].
# a) Faites l’exercice en créant 
# et retournant une nouvelle liste 
# (la liste de départ reste inchangée)
# b) Refaites l’exercice en modifiant 
# la liste de départ (pas de nouvelle liste)

def suppression_doublons_a(ma_liste):
 ma_liste_retour=[ma_liste[0]]
 for i in range(1, len(ma_liste)): 
   #print("indice i = ", i, " len(ma_liste) = ", len(ma_liste))
   if ma_liste[i-1]!=ma_liste[i]:
    ma_liste_retour.append(ma_liste[i])
 return ma_liste_retour

def suppression_doublons_b(ma_liste):
 i=1
 #print("len(ma_liste) = ", len(ma_liste)) 
 while(i<len(ma_liste)):#for i in range(1, len(ma_liste)-1):
   #print("indice i = ", i, "  ma_liste[i] = ", ma_liste[i], " len(ma_liste) = ", len(ma_liste))
   if ma_liste[i-1]==ma_liste[i]:
    #print("**cas de pop **ma_liste = ", ma_liste)
    #print(" cas de pop : i-1 = ", i-1)
    ma_liste.pop(i-1)
    i=i-1
    #print(" aprés pop : i = ", i)
   else:
    i=i+1
   #print("**ma_liste = ", ma_liste)
   #print(" ")

print(" ")
print("-----Le doublons--V1----")  
ma_liste = [7, 3, 3, 8, 8, 8, 7]
print("ma_liste = ", ma_liste)
ma_liste_retour = suppression_doublons_a(ma_liste)
print("ma_liste_retour = ", ma_liste_retour)

print(" ")
print("-----Le doublons--V2----")  
ma_liste = [7, 3, 3, 8, 8, 8, 7]
print("ma_liste = ", ma_liste)
suppression_doublons_b(ma_liste)
print("ma_liste = ", ma_liste)

