#td12_exercice3

mots = ['Carottes', 'Poireaux', 'Tomates', 'Aubergines', 'Courgettes']
print(mots)


for m in mots[:] :
 mots.append(m)

print(mots)
print("**********************************")
print(" ")

mots = ['Carottes', 'Poireaux', 'Tomates', 'Aubergines', 'Courgettes']
print(mots)
print(" ")
print(" ")

for m in mots :
 print(" m = ", m)
 #print("mots = ", mots)
 mots.append(m)
 print("mots = ", mots)
 
#print(mots)
