

mots = ['A', 'B']
print(mots)
print(" ")
print(" ")

for m in mots :
 print(" m = ", m)
 #print("mots = ", mots)
 mots.append(m) # à chaque nouveau mot, le code à l'occasion d'en rajouter un de plus
 print("mots = ", mots)
