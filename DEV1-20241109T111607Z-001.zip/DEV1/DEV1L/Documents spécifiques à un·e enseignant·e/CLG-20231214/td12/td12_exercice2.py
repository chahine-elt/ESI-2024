#td12_exercice2

mots = ['Carottes', 'Poireaux', 'Tomates', 'Aubergines', 'Courgettes']
print(mots)
print("id(mots) = ", id(mots))
mots = mots.append("Brocolis")
print("id(mots) = ", id(mots))
print(mots)

#mots.append("Brocolis")
#print(mots)