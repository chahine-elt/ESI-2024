#td12_exercice4


ma_liste = [x for x in range(25) 
              if x**2 <= 25]
print(ma_liste)

ma_liste = []
for x in range(25):
 if x**2 <= 25:
  ma_liste.append(x)
print(ma_liste)

import random
ma_liste = [random.randint(0,20) for i in range(10)]
print(ma_liste)

#Écrivez une fonction liste_entiers_aléatoires(n, nmin, nmax)
#qui retourne une liste de taille n de nombres entiers 
#choisis aléatoirement entre nmin et nmax inclus. 
#avec liste en compréhension

def liste_entiers_aléatoires(n, nmin, nmax):
 liste_entiers_aléatoires = [random.randint(nmin,nmax+1) for i in range(n)]
 return liste_entiers_aléatoires
 
nmin = int(input("Entrez nmin : "))
nmax = int(input("Entrez nmax : "))
n = int(input("Entrez n : "))
liste_entiers_aléatoires = liste_entiers_aléatoires(n, nmin, nmax)
print(liste_entiers_aléatoires)


# Écrivez une fonction addition(l1, valeur) 
# qui reçoit en paramètre une liste d’entiers (l1)
# et un nombre entier (valeur). 
# Votre fonction retourne une nouvelle liste obtenue 
# en ajoutant à chacun des éléments 
# de la liste l1 le nombre entier valeur. 
# Par exemple si l1 = [1, 2, 3, 4, 5] et valeur = 2, 
# votre fonction retournera la liste [3, 4, 5, 6, 7].

def addition(l1, valeur):
 for i in range(len(l1)) :
  l1[i] = l1[i] + valeur
 return l1

l1=[1, 2, 3, 4, 5]
print(l1)
valeur = int(input("Entrez une valeur : "))
liste_add = addition(l1, valeur)
print(liste_add)


# Écrivez une fonction char_to_int(liste) 
# qui transforme une liste de caractères minuscules
# (non accentués) en une liste d’entiers 
# compris entre 0 et 25. 
# Par exemple "a" sera renvoyé
# sur 0, "b" sera renvoyé sur 1 , etc.
# Par exemple si liste = ['b', 'o', 'n', 'j', 'o', 'u', 'r'], 
# votre fonction retournera la liste d’entiers [1, 14, 13, 9, 14, 20, 17]. 
# Pour tester votre fonction, vous pouvez facilement créer une
# liste de caractères à l’aide de la fonction
# list qui transforme une chaine de caractères
# en une liste de caractères.
# On pourra remarquer que ord("a") renvoie 97 et ord("z") renvoie 122.

liste_entiers=[]
def char_to_int(liste_car):
  for i in range(len(liste_car)) :
   print(liste_car[i])
   liste_entiers.append(ord(liste_car[i])-97)
  return liste_entiers

liste_car= ['b', 'o', 'n', 'j', 'o', 'u', 'r']
#[1, 14, 13, 9, 14, 20, 17]
print(liste_car)
liste_entiers = char_to_int(liste_car)
print(liste_entiers)




