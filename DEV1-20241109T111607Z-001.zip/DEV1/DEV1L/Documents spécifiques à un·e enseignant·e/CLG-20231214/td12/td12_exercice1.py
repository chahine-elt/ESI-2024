# TD12 exercice 1

import random

ma_liste = []

def display():
 print(ma_liste)


for i in range(10):
 ma_liste.append(random.randint(0,5))

print(ma_liste)

caracteres = "abcdefghijklmnopqrstuvwxyz"

ma_liste = []

for i in range(10):
 ma_liste.append(random.choice(caracteres))

print(ma_liste)

# créez une liste liste1 contenant quelques entiers ;
ma_liste = [0, 1, 2, 3]
# vérifiez la longueur de liste1 ;
print(len(ma_liste))
# à l’aide de l’opérateur in vérifier la présence de la valeur 0 ;
for i in range(len(ma_liste)):
 if (ma_liste[i]==0):
  print("0 est bien dans la liste")
 
# ajoutez à cette liste, en dernière position, la valeur 15 ;
ma_liste.append(15)
display()

# inversez l’ordre des éléments de la liste ;
ma_liste.reverse()
display()

# utilisez le slicing pour créer une nouvelle liste (liste4) contenant les éléments
# d’indice pair de la liste1 ;
list4=ma_liste[0:len(ma_liste):2]
display()
print(list4)
# grâce à la méthode count, comptez le nombre d’occurrences dans cette liste de la
# valeur 3 ;
display()
print(ma_liste.count(3))
# insérez en deuxième position la valeur 7 ;
print(len(ma_liste))
ma_liste.insert(1, 7)
print(ma_liste)
# On distingue insérer et modifier. Comment mettez vous en évidence la différence ?
print(len(ma_liste)) # un élément de plus
del ma_liste[1]
print(ma_liste)
print(len(ma_liste))
ma_liste[1]=7
print(len(ma_liste))
print(ma_liste)
# en utilisant le slicing, remplacez le deuxième et le troisième élément de liste1 par
# les éléments de la liste [10,12,14,16] ;
ma_liste[2:4] = [10,12,14,16]
print(ma_liste)#http://pascal.ortiz.free.fr/contents/python/slices/slices.html
# à l’aide de la méthode copy de la classe list, créez une copie de liste1 nommée
# liste2. 
liste2=ma_liste.copy()
print(liste2)
print("identifiant de ma_liste : ", id(ma_liste))
print("identifiant de liste2 : ", id(liste2))
#Exécutez ensuite l’instruction liste3 = liste1. Quelle est la différence entre
# ces deux instructions ?
liste3=ma_liste
print(liste3)
print("identifiant de liste3 : ", id(liste3))
# extrayez de la liste1 le dernier élément ;
print(ma_liste)
ma_liste.pop()
print(ma_liste)
# extrayez de la liste1 l’élément en 4ème position ;
del ma_liste[3]
print(ma_liste)
# triez liste1 en ordre ascendant (du plus petit au plus grand) ;
ma_liste.sort()
print(ma_liste)
# triez liste2 en ordre descendant (du plus grand au plus petit) ;
print(liste2)
liste2.sort(reverse=True)
print(liste2)
# recherchez l’indice d’une valeur présente dans liste2 ;
print(liste2.index(15))
# recherchez l’indice d’une valeur non présente dans liste2 ;
# print(liste2.index(13))
# print(liste2.index(17))
# supprimez une valeur présente dans liste2 ;
print(liste2)
liste2.remove(15)
print(liste2)
liste2.append(15)
print(liste2)
liste2.append(15)
print(liste2)
liste2.remove(15)
print(liste2)
# que se passe-t-il si vous supprimez une valeur non présente dans liste2 ?
#liste2.remove(13)
#print(liste2)
# à l’aide de la méthode extend de la classe list, ajoutez à la fin de liste1 les éléments
# de liste2 situés entre la 3ième et la 7ième position inclues ;
# print(ma_liste)
# print(liste2)
# ma_liste.extend(liste2)
# print(ma_liste)
print("**********")
#ma_liste=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
print(ma_liste)
print(liste2)
liste2.append(7)
print(liste2)
print(liste2[3:6])
ma_liste.extend(liste2[3:6])
print(ma_liste)
print("**********")
# supprimez toutes les valeurs de liste2 ;
print(liste2)
liste2.clear()
print(liste2)
# à l’aide de la fonction del supprimez le premier élément de liste1
print(ma_liste)
print(len(ma_liste))
del ma_liste[0]
print(ma_liste)
print(len(ma_liste))