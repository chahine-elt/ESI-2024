def est_pair (x):
 return x%2 == 0