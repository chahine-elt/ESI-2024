# volume sphère

import math

def volume_sphere(r):
 return (4/3)*math.pi*math.pow(r,3)