import nombres

x = int(input('Entrez un nombre entier : '))

if (nombres.est_pair(x)):
 print(nombres.est_pair(x))
 print('Ce nombre est pair')
else:
 print(nombres.est_pair(x))
 print('Ce nombre est impair')
