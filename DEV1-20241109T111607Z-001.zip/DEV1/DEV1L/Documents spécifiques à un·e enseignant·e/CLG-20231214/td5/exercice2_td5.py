# *** L'instruction return en Python ***

def afficher(x):
 print(x)
 print("Les fonctions en Python")
 return 0
 # print("Les fonctions en Python ne s'affichera pas car après le return")


afficher(5)
afficher('salut')
afficher([1,2,3])