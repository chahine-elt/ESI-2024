import affichage

# Affiche 5 étoiles
affichage.afficher_etoiles(5)
# Affiche 10 étoiles
affichage.afficher_etoiles(10)

car = input('Entrez un caractère : ')
n = int(input('Entrez le nombre d\'affichages du caractère : '))
affichage.affichage(n,car)

