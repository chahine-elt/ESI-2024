import volume_sphère

r = int(input('Entrez la rayon de la sphère : '))
print("Le volume de la sphère de rayon", r, " est : ", 
volume_sphère.volume_sphere(r))

# python main_volume_sphère.py
# Entrez la rayon de la sphère : 3
# Le volume de la sphère de rayon 3  est :  113



