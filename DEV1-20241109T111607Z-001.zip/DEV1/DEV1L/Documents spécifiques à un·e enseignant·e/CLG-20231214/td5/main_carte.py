import carte


ma_carte = carte.tirer_carte()
print("Voici ma carte tirée au hasard:")
print(ma_carte)