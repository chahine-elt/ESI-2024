import couleur


ma_couleur = couleur.couleurs()
print("Voici ma couleur tirée au hasard:")
print(ma_couleur)