# Code du module contenant des fonctions

# Une fonction calculant le périmètre d'un cercle de rayon donné:
 def perimetre_cercle(rayon):
 return 2*3.14*rayon

# Une fonction calculant l'aire d'un cercle de rayon donné:
 def aire_cercle(rayon):
 return 3.14*rayon*rayon


# Eventuelles autres fonction en rapport avec le cercle ..