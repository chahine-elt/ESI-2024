import lettres


mes_lettres = lettres.lettres()
print("Voici trois lettres de l'alphabet tirées au hasard:")
print(mes_lettres[0], mes_lettres[1], mes_lettres[2])