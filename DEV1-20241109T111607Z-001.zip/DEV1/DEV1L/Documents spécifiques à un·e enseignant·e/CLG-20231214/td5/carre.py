# Code du module contenant des fonctions


# Une fonction calculant l'aire d'un carré de côté x donné:
def aire_carré(x):
 return x*x

