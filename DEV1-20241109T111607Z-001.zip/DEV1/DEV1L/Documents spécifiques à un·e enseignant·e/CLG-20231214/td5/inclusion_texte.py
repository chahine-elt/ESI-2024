# contient(texte1,texte2)
def est_inclus (texte1, texte2):
 return (texte1 in texte2 or texte2 in texte1)