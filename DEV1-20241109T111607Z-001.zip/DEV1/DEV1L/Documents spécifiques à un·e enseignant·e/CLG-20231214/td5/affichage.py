# Fonction qui affiche n étoiles à l'écran
def afficher_etoiles (n):
 print(n*'*')
# Aucun return: la fonctions se contente d'afficher des étoiles

def affichage(n,car):
 print(n*car)