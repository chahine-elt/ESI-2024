# Écrivez une fonction afficher_boite(n) qui affiche à l’écran une boite vide (= un rectangle
# avec un bord mais d’intérieur vide, voir l’illustration ci-dessous) constitué de n étoiles
# de largeur et de 4 étoiles de hauteur.
# Par exemple, l’appel de fonction afficher_boite(10) affiche




def afficher_boite(n):
 print(n*'*')
 print('*',(n-4)*' ','*')
 print('*',(n-4)*' ','*')
 print(n*'*')