# Écrivez une fonction afficher_boite(n) qui affiche à l’écran une boite vide (= un rectangle
# avec un bord mais d’intérieur vide, voir l’illustration ci-dessous) constitué de n étoiles
# de largeur et de 4 étoiles de hauteur.
# Par exemple, l’appel de fonction afficher_boite(10) affiche

import afficher_boite

n = int(input("Entrez la taille de la boite en longueur : "))

afficher_boite.afficher_boite(n)
