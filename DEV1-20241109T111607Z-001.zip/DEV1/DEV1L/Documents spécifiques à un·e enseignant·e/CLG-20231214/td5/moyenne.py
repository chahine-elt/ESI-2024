# moyenne de 3 nombres


def moyenne(a, b, c):
 return (a+b+c)/3