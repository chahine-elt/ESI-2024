def f(x = 0, y, z = 0):
print("f(", x, ",", y, ",", z, ")")

print(f(1,2))