def square_no_print(x):
 return x**2

def square_print(x):
 print(x**2)
