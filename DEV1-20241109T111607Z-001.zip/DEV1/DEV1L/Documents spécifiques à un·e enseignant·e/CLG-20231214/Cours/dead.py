def f():
 return 42
 print("Snakes...why'd it have to be snakes?")

print(f())