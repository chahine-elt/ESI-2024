l = [1, 2, 3, 4, 5]
print(l)
l[0] = 42
print(l)
