import circle

r = 2
b=circle.area(r)
circ=circle.circumference(r)
print("A circle of radius", r, "has area", b)
print("A circle of radius", r, "has circumference", circ)
circle.print_area_formula()
circle.print_circle_info(r, b, circ)
