def est_pair(x):
 return x % 2 == 0

print(est_pair(3))
print(est_pair(6))

print(5 < 2)
print(2 <= 5 < 9)
x = 5 < 2
print(x)
x = False
print(1 < 3 and x)
b = est_pair(5) or 5 > 2
print("b = ", b)
b = not x
print("not x : ", b)

x = int(input("Entrez un nombre entier x : "))
if x > 0 :
 print("x est positif")
elif x > 0 :
 print("x est négatif")
else :
 print("x est nul")
print("Merci d'avoir participé !")

print("*****************")
n = 10
if n % 2 == 0:
 print("Ce nombre est pair")
elif n % 5 == 0:
 print("Ce nombre est un multiple de 5")
elif n % 10 == 0:
 print("Ce nombre est un multiple de 10")
else:
 print("Ce nombre n'est pas un multiple de 2, 5 ou 10")

print("*****************")
n = 10
if n % 10 == 0:
 print("Ce nombre est un multiple de 10")
elif n % 2 == 0:
 print("Ce nombre est pair")
elif n % 5 == 0:
 print("Ce nombre est un multiple de 5")
else:
 print("Ce nombre n'est pas un multiple de 2, 5 ou 10")
print("*****************")

n = 10
if n % 2 == 0:
 print("Ce nombre est pair")
if n % 5 == 0:
 print("Ce nombre est un multiple de 5")

print("*****************")

n = 8
if n % 2 == 0:
 print("Ce nombre est pair")
else :
 print("Ce nombre est impair")
if n % 5 == 0:
 print("Ce nombre est un multiple de 5")
else :
 print("Ce nombre n'est pas un multiple de 5")

print("*****************")


def jour_de_semaine(x):
 match x:
  case 1:
   return "Lundi"
  case 2:
   return "Mardi"
  case 3:
   return "Mercredi"
  case 4:
   return "Jeudi"
  case 5:
   return "Vendredi"
  case 6:
   return "Samedi"
  case 7:
   return "Dimanche"
  case _:
   return None

s = jour_de_semaine(5)
print(s)
s = jour_de_semaine(0)
print(s)
s = jour_de_semaine(9)
print(s)

#dans cet exemple, on peut remplacer le while par un for 
#car ici je connais le nombre d'itérations en avance (ici 3)
start = 3
while start > 0 : 
 print(start)
 start = start - 1
print("Partez !")

#impossible de remplacer le while par un for 
#car on ne connait pas le nombre d'itérations en avance
active = True
while (active) :
 message = input("Dis-moi quoi répéter, ou entre 'quit' pour arrêter : ")
 if message == "quit":
  active = False
 else :
  print(message)


# while True:
 # print("Je ne m'arrête jamais !")
 
i = 10
while i > 0 :
 if i > 0:
  print ("Encore ", i, " étapes !")
  i = i-1
 else :
  print ("On est arrivés !")
  
i = 10
while i >= 0 :
 if i > 0:
  print ("Encore ", i, " étapes !")
  i = i-1
 else :
  print ("On est arrivés !")
  i = i-1


str = ""
for lettre in "hello":
 str += lettre
print(str)

print("*****for n in range(5):*****")
for i in range(5):
 print(i)

print("*****for n in range(3,0,-1):*****")
for n in range(3,0,-1):
 print(n)
print("Partez !")

print("**On ne rentre pas dans la boucle***for n in range(3,0,1):*****")
print("*3 est plus grand que 0***for n in range(3,0,1):*****")
for n in range(3,0,1):
 print(n)
print("Partez !")


print("**Boucle finie ***for n in range(3,10,1):*****")
for n in range(3,10,1):
 print(n)
print("Partez !")

print("**Boucle infinie ***for n in range( ):*****")
# for n in range( ):
 # print(n)
# print("Partez !")

print("")
print("-------Boucles imbriquées-------")
for i in range(2):
 print("Première boucle itération : ", i)
 for j in range(2):
  print("Deuxième boucle itération : ", j)
  #Code utile
  print("Fin de l'itération : ", j, " de la deuxième boucle")
 print("Fin de l'itération : ", i, " de la première boucle")

print("")
print("Récursivité")

def factorielle_boucle(n):
 resultat = 1
 for i in range(1, n+1):
  resultat *= i
 return resultat


print(factorielle_boucle(5))

def factorielle_recur(n):
 if n == 0:
  return 1
 else:
  return n * factorielle_recur(n-1)

print(factorielle_recur(5))

 