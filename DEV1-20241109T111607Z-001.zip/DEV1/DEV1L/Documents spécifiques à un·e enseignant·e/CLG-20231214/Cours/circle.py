import math

def area(r):
 a = math.pi*r*r
 return a

def circumference(r):
 return 2*math.pi*r*r

def print_area_formula():
 print("Area computed as 'pi*r*r'")

def print_circle_info(r, a, circ):
 print("Circle of radius", r, "has area", a, "and circumference", circ)