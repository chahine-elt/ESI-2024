import passage_immuables

x = 2
y = passage_immuables.pass_int(x)
print("x = ", x)
print("y = ", y)
print()

t = (1,2)
t2 = passage_immuables.pass_tuple(t)
print("t = ", t)
print("t2 = ", t2)
print()

t = (1,2)
t2 = passage_immuables.pass_tuple2(t)
print("t = ", t)
print("t2 = ", t2)
print()
