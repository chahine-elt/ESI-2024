import param_def

param_def.hello()
param_def.hello("there!")