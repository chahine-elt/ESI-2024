import multiple_returns

a, b = multiple_returns.double_square(3)
print("Twice", 3, "is", a)
print("Squared", 3, "is", b)

tup = multiple_returns.double_square(3)
print("Twice", 3, "is", tup[0])
print("Squared", 3, "is", tup[1])
print(tup)
