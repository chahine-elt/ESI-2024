# structures de données 

vide = [] # empty list
compte = [1, 2, 3] # list of integers
fruits = ["apple", "banana", "cherry", "kiwi", "mango"] # list of strings
quelconque = ["texte", 5, 2.0, ["a", "b", "c"]] # list of any elements

print("vide = ", vide)
print("compte = ", compte)
print("fruits = ", fruits)
print("quelconque = ", quelconque)

liste = [2+2, 3 > 1, abs(-5)]
print("liste évaluée = ", liste)

liste = [1, 2, 3]
print("liste = ", liste)
len(liste)
print("longueur de la liste = ", len(liste))
print("liste[0] = ", liste[0])
print("liste[2] = ", liste[2])
#print("liste[3] = ", liste[3])
print("liste[-1] = ", liste[-1])
print("liste[-2] = ", liste[-2])
print("liste[-3] = ", liste[-3])
#print("liste[-4] = ", liste[-4])
liste[2]=4
print("liste[2]=4")
print("liste = ", liste)
liste[-2] = 5
print(" liste[-2] = 5")
print("liste = ", liste)
#liste[4] = 6
print("*********slicing********")
liste = [1, 2, 3, 4, 5, 6, 7]
print(liste)
print("liste[1:4] = ", liste[1:4])
print("liste[2:-2] = ", liste[2:-2])
print("liste[-4:5] = ", liste[-4:5])
print(" ")
print("liste[5:5] = ", liste[5:5])
print("liste[5:4] = ", liste[5:4])
print("liste[7:10] = ", liste[7:10])
print("liste[5:10] = ", liste[5:10])
print(" ")
liste = [1, 2, 3, 4, 5, 6, 7]
print("liste = ", liste)
print("liste[:4] = ", liste[:4])
print("liste[4:] = ", liste[4:])
print("liste[:] = ", liste[:])
print(" ")
liste = [1, 2, 3, 4, 5, 6, 7]
print("liste = ", liste)
liste[1:6:2]
print("liste[1:6:2] = ", liste[1:6:2])
liste[5:1:-3]
print("liste[5:1:-3] = ", liste[5:1:-3])
liste[:3:-1]
print("liste[:3:-1] = ", liste[:3:-1])
liste[::-1]
print("liste[::-1] = ", liste[::-1])

print(" ")
liste = [1, 2, 3, 4, 5, 6, 7]
print("liste = ", liste)
liste[3:5] = [8]
print("liste[3:5] = [8] : ", liste)
print("nouvelle liste : ", liste)
#liste[2:4] = 9
#print("liste[2:4] = 9 : ", liste)
# liste[2:4] = [9] ça fonctionne
# print("liste[2:4] = [9] : ", liste)
liste[2:4] = [9, 10, 11]
print("liste[2:4] = [9, 10, 11] : ", liste)
print("len(liste) = ", len(liste))
liste[len(liste):] = [8]
print("liste[len(liste):] = [8] : ", liste)


sum = 0
for element in [1, 2, 3]:
 sum += element
print("parcours somme des élémenst d'une liste : ", sum) # 6

liste = [1,2,3]
for i in range(len(liste)) :
 liste[i] = liste[i]*2
print("liste[i] = liste[i]*2 : ", liste) # [2, 4, 6]

liste = [1,2,3]
for index, value in enumerate(liste) :
 liste[index] = value*2
print("for index, value in enumerate(liste) : ", liste) # [2, 4, 6]

print("-- insertion et suppression ---")
liste = [1, 2, 3, 4, 5, 6, 7]
print("liste : ", liste)
liste.append(8)
print("liste.append(8) : ", liste)
liste = [1, 2, 3, 4, 5, 6, 7]
print("liste : ", liste)
liste.insert(3,9)
print("liste.insert(3,9) : ", liste)
liste.insert(-2,10)
print("liste.insert(-2,10) : ", liste)
print("len(liste) = ", len(liste))
liste.insert(13,11)
print("liste.insert(13,11) : ", liste)
liste.insert(-13,0)
print("liste.insert(-13,0) : ", liste)

liste = [1, 2, 3, 4, 5, 6, 7]
print("liste : ", liste)
print("len(liste) = ", len(liste))
liste.remove(5)
print("liste.remove(5) : ", liste)
print("len(liste) = ", len(liste))
#liste.remove(10)

liste = [1, 2, 3, 4, 5, 6, 7]
print("liste : ", liste)
liste.pop()
print("liste.pop() : ", liste)
liste.append(7)
print("liste : ", liste)
liste.pop(1)
print("liste.pop(1) : ", liste)
liste.pop(-3)
print("liste.pop(-3) : ", liste)
print("len(liste) = ", len(liste))
#liste.pop(13)

print(" ")
liste = [1, 2, 3, 4, 5, 6, 7]
print("liste : ", liste)
liste.extend([10, 11])
print("liste.extend([10, 11]) : ", liste)

liste = [1, 2, 3, 4, 5, 6, 7]
print("liste : ", liste)
liste.clear()
print("liste.clear() : ", liste)

liste = [1, 2, 3, 4, 5, 6, 7]
print("liste : ", liste)
del liste[3]
print("del liste[3] : ", liste)
liste = [1, 2, 3, 4, 5, 6, 7]
print("liste : ", liste)
#liste.pop(3)
print("valeur retournée par liste.pop(3) = ", liste.pop(3))
print("liste.pop(3) : ", liste)

liste = [1, 2, 3, 4, 5, 6, 7]
print("liste = ", liste)
print("3 in liste = ", 3 in liste)
print("8 in liste = ", 8 in liste)

liste = [1, 2, 3, 4, 5, 6, 7]
print("liste = ", liste)
print("liste.index(3) = ", liste.index(3))
#print("liste.index(9) = ", liste.index(9))
repeat = [3, 4, 3]
print("repeat.index(3) = ", repeat.index(3))

def affiche_position(liste, elem) :
 if elem in liste :
  print("L'élément " + str(elem) + " se trouve à la position " + str(liste.index(elem)) + ".")
 else :
  print("L'élément " + str(elem) + " ne se trouve pas dans la liste.")

print(" ")
print("affiche_position")

liste = [1, 2, 3, 4, 5]
print("liste = ", liste)
print("affiche_position(liste, 3) : ", affiche_position(liste, 3))
print("affiche_position(liste, 7) : ", affiche_position(liste, 7))

liste = [1, 2, 3, 4, 5, 6, 2, 2, 7]
print("liste = ", liste)
print(" liste.count(2) = ", liste.count(2))
print(" liste.count(9) = ", liste.count(9))

liste = [1, 2, 3, 4, 5, 6, 7]
print("liste = ", liste)
liste.reverse()
print("liste.reverse() = ", liste)

print("----sort----")
liste = [1, 6, 5, 2, 3, 7, 4]
print("liste = ", liste)
liste.sort()
print("liste.sort() = ", liste)
liste = [1, 6, 5, 2, 3, 7, 4]
print("liste = ", liste)
liste.sort(reverse=True)
print("liste.sort(reverse=True) = ", liste)

squares = []
print("squares = ", squares)
for i in range(1,11):
 squares.append(i**2)
print("squares.append(i**2) = ", squares)

#Reprendre ici au cours du 4/12/2023
print("Reprendre ici au cours du 4/12/2023")
squares = [i**2 for i in range(1,11)]

print(squares)

print("sans append")
fruits = ["apple", "banana", "cherry", "kiwi", "mango"]
newlist = [x for x in fruits if "a" in x]
print("id of fruits", id(fruits))
print("id of newlist", id(newlist))
print()


print(fruits)
print(newlist)

print("sans append")

print()
print()
print("avec append")
fruits = ["apple", "banana", "cherry", "kiwi", "mango"]
newlist = []
print("id of newlist  = []", id(newlist))
for x in fruits :
 if "a" in x:
  newlist.append(x)

print(fruits)
print(newlist)

print("id of fruits", id(fruits))
print("id of newlist", id(newlist))
print("avec append")

print()


print("************passage aux tuples ************")
squares = [i**2 for i in range(1,11)]
for square in squares :
 print(square)

print()

for i in range(1,11) :
 print(i**2)

print()

vide = () # empty tuple
print("vide = ", vide)
compte = (1, 2, 3) # tuple of integers
print("compte = ", compte)
quelconque = ("texte", 5, 2.0) # tuple of any elements
print("quelconque = ", quelconque)
unseul = (1,) # tuple with a single element
print("unseul = ", unseul)

print()

vide = tuple()
print("vide = ", vide)
letters = tuple("Hello !")
print("letters = ", letters)
fruits = tuple(["apple", "banana", "cherry", "kiwi", "mango"])
print("fruits = ", fruits)
squares = tuple(i**2 for i in range(1,11))
print("squares = ", squares)

print()


fruits = ("apple", "banana", "cherry", "kiwi", "mango")
print("fruits[0] = ", fruits[0])
print("fruits[-1] = ", fruits[-1])
print("fruits[2::1] = ", fruits[2::1])
print("à l'itération 2 crans plus loin, fruits[2::2] = ", fruits[2::2])

fruits = ("apple", "banana", "cherry", "kiwi", "mango", "apple")
if "apple" in fruits :
 print("la pomme est dans les fruits")
print(" fruits.index(str(apple))",  fruits.index("apple"))
print(" fruits.index(str(cherry))",  fruits.index("cherry"))
print("fruits.count(str(apple))", fruits.count("apple"))


a, b = (7, 13)
print("a = ", a)
print("b = ", b)

temp = b
b = a
a = temp

print("permutation avec variable temp")
print("a = ", a)
print("b = ", b)

print("permutation avec a, b = b, a")
a, b = b, a
print("a = ", a)
print("b = ", b)

print("************passage aux ensembles ************")

def min_max(iterable):
 min = max = iterable[0]
 for n in iterable:
  if n < min:
   min = n
  if n > max:
   max = n
 return min, max

print(min_max(range(7,13))) # (7, 8, 9, 10, 11, 12)
min, max = min_max(range(7,13))
print(min) # 7
print(max) # 12

s = {1, 2, 3, 4}
print("s= ", s)
multiples={1, 2, "trois"}
print("multiples= ", multiples)
duplicates = {1, 1, 2, 3, 4}
print("duplicates= ", duplicates)
nb_pairs = {i for i in range(2,11,2)}
print("nb_pairs = {i for i in range(2,11,2)} : ", nb_pairs)

spell = set("abracadabra")
print("spell = ", spell)

print("taille de spell : ", len(spell))
print("a in spell : ", "a" in spell)
print("k in spell : ", "k" in spell)

sum = 0
print("nb_pairs = {i for i in range(2,11,2)} : ", nb_pairs)
for i in nb_pairs :
 sum += i

print("sum des pairs de l'ensemble = ", sum)


words = "the quick brown fox jumps over the lazy dog".split(" ")
sentence = set(words)
print("words = ", words)
print("sentence = ", sentence)
new_sentence = ""
print("new_sentence = ", new_sentence)
for word in sentence :
 new_sentence += word + " "
print("new_sentence = ", new_sentence)


s = {1, 2, 3, 4}
print("s=", s)
s.add(5)
print("s=", s)
s.remove(4)
print("s après remove 4 =", s)
s.remove(5)
print("s=", s)
print("s après remove 5 =", s)
#s.remove(5)
#print("s=", s)

s = {1, 2, 3, 4}
print("s=", s)
s.discard(4)
print("s=", s)
s.discard(5)
print("s=", s)

s = {1, 2, 3, 4}
print("s=", s)
print("s.pop()=", s.pop())
print("s.clear()=", s.clear())


a = {1, 2, 3, 4}
b = {i for i in range(10)}
c = {1, 2, 3, 4}
print("a :", a)
print("b :", b)
print("c :", c)
print("a < b : ", a < b)
print("b>a : ", b>a)
print("a < c : ", a < c)
print("a <= b : ", a<=b)
print("a <= c : ", a<=c)
print("a >= c : ", a >= c)
print("a == c : ", a == c)
print("a == b : ", a == b)
print("a != b : ", a != b)

a = set("abracadabra")
b = set("alacazam")
print("a = set de abracadabra", a)
print("b = set de alacazam", b)
print("a | b = ", a | b)
print("a & b = ", a & b)
print("a - b = ", a - b)
print("a ^ b = ", a ^ b)



print("*************dictionnaire***********")
vide = {} # empty dictionnary
print("type(vide) = ", type(vide))
traduction = {"one" : "un", "two" : "deux", "three" : "trois"}
print(traduction)
multiples = {1: "objet 1", "deux" : "objet 2", "trois" : 3}
print(multiples)
emails = {("Turing", "Alan") : "aturing@npl.co.uk", ("Lovelace", "Ada") : "ada@lovelace.co.uk"}
print(emails)
# liste_cle = {["apple", "orange"] : 2}

# à continuer le 11/12/23

squares = {i : i**2 for i in range(1,11)}
print("squares = {i : i**2 for i in range(1,11)} : ")
print(squares)

matricules_noms = ((72634, "Maurice Convert"), (82647, "Keeley Pattison"), (28374, "Keri Sadiq"))
print("matricules_noms : ")
print(matricules_noms)
students = dict(matricules_noms)
print("students = dict(matricules_noms)")
print(students)


traduction = {"one" : "un", "two" : "deux", "three" : "trois"}
print("traduction = ")
print(traduction)
print("len(traduction) = ")
print(len(traduction))

print("traduction[\"one\"] : ")
print(traduction["one"])
print("traduction[\"three\"] : ")
print(traduction["three"])
#print("traduction[\"five\"] : ")
#print(traduction["five"])


print("avec get et valeur par défaut, one")
print(traduction.get("one","je ne sais pas"))
print("avec get et valeur par défaut, three")
print(traduction.get("three","je ne sais pas"))
print("avec get et valeur par défaut, five")
print(traduction.get("five","je ne sais pas"))

print("avec get sans valeur par défaut, one")
print(traduction.get("one"))
print("avec get sans valeur par défaut, three")
print(traduction.get("three"))
print("avec get sans valeur par défaut, five")
print(traduction.get("five"))

print("la liste des clés du dico traduction")
print(list(traduction))
print("la liste des clés triées du dico traduction")
print(sorted(traduction))
dico_mixte = {"c" : 1, "abc" : 2, 5 : 3, 3 : 2}
print("dico mixte : ", dico_mixte)
print("la liste des clés du dico mixte")
print(list(dico_mixte))
# print("la liste des clés triées du dico mixte")
# print("et ça se passe mal...")
# sorted(dico_mixte)


traduction = {"one" : "un", "two" : "deux", "three" : "trois"}
print("traduction")
print(traduction)
print("one in traduction = ", "one" in traduction)
print("five in traduction = ", "five" in traduction)

print("ajout et suppression dans le dictionnaire : ")
traduction = {"one" : "un", "two" : "deux", "three" : "trois"}
print("traduction = ", traduction)
traduction["four"] = "quatre"
print("traduction = ", traduction)
traduction["four"] = "pas quatre"
print("changement de la traduction de four = ")
print(traduction)
del traduction["four"]
print("suppression de la clé four = ")
print(traduction)
# print("suppression de la clé five qui n'est pas une clé du dico = ")
# del traduction["five"]
print("traduction.pop du premier one")
print(traduction.pop("one"))
print(traduction)
print("traduction.clear()")
print(traduction.clear())
print(traduction)

print("")
traduction = {"one" : "un", "two" : "deux", "three" : "trois"}
print("parcours des clés du dico")
for k in traduction:
 print(k)

print("")
print("parcours des valeurs du dico")
for k in traduction:
 print(traduction[k])

print("")

print("traduction.items()")
print(traduction.items())
for clé, valeur in traduction.items():
 print("Le mot anglais " + clé + " veut dire " + valeur + " en francais")
 
































