def change_first_elem(l, i):
 print("Id of l inside fct before set :", id(l))
 l[0] = i
 print("Id of l inside fct after set :", id(l))

def reaffect(l1, l2):
 print("Id of l1 inside fct before = :", id(l1))
 print("l1 inside fct before = :", l1)
 print("Id of l2 inside fct before = :", id(l2))
 print("l2 inside fct before = :", l2)
 l1 = l2
 print("Id of l1 inside fct after = :", id(l1))
 return l1