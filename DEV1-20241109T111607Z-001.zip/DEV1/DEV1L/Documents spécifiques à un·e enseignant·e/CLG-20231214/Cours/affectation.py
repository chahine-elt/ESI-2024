x = 2
y = x
z = 2

print("id of x", id(x))
print("id of y", id(y))
print("id of z", id(z))
print()

x = 4
print("id of x", id(x))
print("id of y", id(y))
print("id of z", id(z))