import order_eval

print(order_eval.f(order_eval.g1(), order_eval.g2(), order_eval.g3()))