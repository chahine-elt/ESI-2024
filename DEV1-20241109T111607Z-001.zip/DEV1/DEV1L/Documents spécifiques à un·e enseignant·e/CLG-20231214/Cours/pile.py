def f(x):
 return x + g(x)

def g(y):
 return x * y
 

print(f(2))