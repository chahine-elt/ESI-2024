import no_return

x = no_return.say_hello()
print(x)

print(no_return.say_hello())