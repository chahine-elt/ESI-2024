def is_even(x):
 if x % 2 == 0:
  return True
 else:
  return False

print(is_even(1))
print(is_even(2))
print(is_even(3))
print(is_even(4))
