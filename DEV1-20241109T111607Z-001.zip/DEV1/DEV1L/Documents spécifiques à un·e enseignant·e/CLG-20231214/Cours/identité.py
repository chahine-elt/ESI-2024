x = 2
print("id of x", id(x))
print()

y = 3
print("id of y", id(y))
print()

z = x
print("id of x", id(x))
print("id of z", id(z))
print()

s = "Hello World!"
print("id of s", id(s))