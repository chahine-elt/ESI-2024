def f(x, y, z):
 print("Calling f")
 return 0

def g1():
 print("Calling g1")
 return 1

def g2():
 print("Calling g2")
 return 2

def g3():
 print("Calling g3")
 return 3