def pass_int(x):
 print("Id of x inside fct before = :", id(x))
 x = 42
 print("Id of x inside fct after = :", id(x))
 return x

def pass_tuple(t):
 print("Id of t inside fct before = :", id(t))
 t = (42, 23)
 print("Id of t inside fct after = :", id(t))
 return t