import print_vs_return

x = print_vs_return.square_no_print(3)
x = x + 2
print(x)
print()

#print_vs_return.square_print(3)

x = print_vs_return.square_print(3)
#x = x + 2
print(x)