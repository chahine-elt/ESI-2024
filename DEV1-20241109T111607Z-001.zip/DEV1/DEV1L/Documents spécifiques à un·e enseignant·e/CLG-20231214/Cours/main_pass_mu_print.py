import pass_mu_print

l1 = [1, 2, 3]
l2 = [23, 42, 404]
print("Id of l1 outside fct :", id(l1))
print(l1)
print("Id of l2 outside fct :", id(l2))
print(l2)
print()

pass_mu_print.change_first_elem(l1, 42)
print(l1)
print("Id of l1 outside fct :", id(l1))
print("--------------------------------------")

print(l1)
print("Id of l1 outside fct :", id(l1))
print(l2)
print("Id of l2 outside fct :", id(l2))
l3=pass_mu_print.reaffect(l1, l2)
print(l1)
print("Id of l1 outside fct :", id(l1))
print(l3)
print("Id of l1 outside fct :", id(l3))
print()
