def hello(name="World!"):
 print("Hello", name)
