t = (1,2) #creates a tuple
print(t)
#t[0] = 42 #error
print(t[0])

s = "Hello World!"
print(s)
#s[0] = "t" #error
print(s[0])
