def double_square(x):
 return 2*x, x**2