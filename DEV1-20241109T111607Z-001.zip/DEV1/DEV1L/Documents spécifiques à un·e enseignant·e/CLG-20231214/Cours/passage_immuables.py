def pass_int(x):
 x = 42
 return x

def pass_tuple(t):
 t = (42, 23)
 return t

def pass_tuple2(t):
 #t[0] = 42
 return t