import pass_immu_print

x = 2
print("Id of x outside fct before calling :", id(x))
y=pass_immu_print.pass_int(x)
print("Id of x outside fct after calling :", id(x))
print(x)
print("Id of y outside fct after calling :", id(y))
print(y)
print()

t = (1,2)
print("Id of t outside fct before calling :", id(t))
t2=pass_immu_print.pass_tuple(t)
print("Id of t outside fct after calling :", id(t))
print(t)
print("Id of t2 outside fct after calling :", id(t2))
print(t2)
