# exercice 2
# nombres de -n à +n

nb = int(input("Entrez un nombre entier : "))
compteur = -1*nb
   
while(compteur <= nb):
 print(compteur)
 compteur = compteur + 1


print("nb de -n à +n Terminé !")