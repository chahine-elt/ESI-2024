# Écrivez un script qui demande un mot à l’utilisateur. Un mot est une chaîne de caractère
# ne contenant aucun espace. Tant que la chaîne entrée par l’utilisateur contient un espace,
# le script affiche un message d’erreur et demande un autre mot à l’utilisateur. (Relisez le
# TD4 pour savoir comment tester qu’une chaîne contient un espace).

mot = input("Entrez un mot : ")

print("Le mot initial est : ", mot)


while(' ' in mot):
 print(" le mot ne doit pas contenir d'espace, trouvez en un autre ")
 mot = input("Entrez un mot : ")
 
print("Le mot sans espace est : ", mot)