
print(" affichage d'un mois en fonction du nombre entré entre 1 et 2")

numéro_mois = int(input("Entrez un nombre entre 1 et 12:"))

while(not(numéro_mois >=1 and numéro_mois <=12)):
# idem que numéro_mois <1 or numéro_mois > 1
 print(" affichez le numéro de mois entre 1 et 2")
 numéro_mois = int(input("Entrez un nombre entre 1 et 12:"))

if numéro_mois==1:
   mois = 'Janvier'
elif numéro_mois==2:
   mois = 'Février'
elif numéro_mois==3:
   mois = 'Mars'
elif numéro_mois==4:
   mois = 'Avril'
elif numéro_mois==5:
   mois = 'Mai'
elif numéro_mois==6:
   mois = 'Juin'
elif numéro_mois==7:
   mois = 'Juillet'
elif numéro_mois==8:
   mois = 'Aout'
elif numéro_mois==9:
   mois = 'Septembre'
elif numéro_mois==10:
   mois = 'Octobre'
elif numéro_mois==11:
   mois = 'Novembre'
elif numéro_mois==12:
   mois = 'Décembre'

print("numéro_mois : ", numéro_mois)
print("mois : ", mois)
