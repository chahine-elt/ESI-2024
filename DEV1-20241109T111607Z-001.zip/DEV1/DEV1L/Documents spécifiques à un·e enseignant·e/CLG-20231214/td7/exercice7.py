# Canevas d'un script lisant une suite de nombres au clavier
nb_valeurs = 0
valeur = int(input("Entrez une suite de nombre entier positifs, terminez par une valeur négative: "))
somme = 0

while(valeur > -1):
 nb_valeurs = nb_valeurs +1
 somme = somme + valeur
 # Faire quelque chose avec le contenu de la variable "valeur" ici
 valeur = int(input("Entrez une autre valeur (ou <0 pour terminer): "))

if nb_valeurs==0:
 print("il faut au moins une valeur positive ou nulle !")
else:
 moyenne = somme/nb_valeurs
 print("La somme vaut : ", somme)
 print("Vous avez entré",nb_valeurs,"valeurs")
 print("La moyenne vaut : ", moyenne)
 