import random

nombre_secret = random.randint(1, 10)
compteur = 1

# print("L'ordinateur a choisi un nombre entre 1 et 10 qui est : ", nombre_secret)
print("L'ordinateur a choisi un nombre entre 1 et 10")
print(" Vous allez devoir le deviner !")

nombre_utilisateur = int(input("Entrez un nombre:"))

while(nombre_utilisateur != nombre_secret):
 compteur = compteur + 1
 nombre_utilisateur = int(input("Raté ! Essayez encore: "))

print("Bravo, vous avez réussi en !", compteur, " fois")