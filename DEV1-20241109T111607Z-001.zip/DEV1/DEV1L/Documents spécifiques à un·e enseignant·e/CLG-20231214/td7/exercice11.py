# Écrivez un script qui demande à l’utilisateur une série de nombres positifs qui se termine
# par -1 (valeur sentinelle). Le programme affiche le maximum et le minimum de la série.
# Par exemple, si l’utilisateur entre : 5 9 2 5 12 7 4 3 -1
# le programme affiche
# maximum : 12
# minimum: 2

valeur = int(input("Entrez une suite de nombre entier positifs, terminez par une valeur négative: "))
minimum=valeur
maximum=valeur

while(valeur > -1):
 if valeur<minimum:
  minimum = valeur
 if valeur>maximum:
  maximum = valeur
 valeur = int(input("Entrez une autre valeur (ou <0 pour terminer): "))


  


print("le min est : ", minimum)
print("le max est : ", maximum)