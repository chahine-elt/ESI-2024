# exercice 1
compteur = 1

nb = int(input("Entrez un nombre entier : "))


while(compteur <= nb):
    print(compteur)
    compteur = compteur + 1

print("Terminé !")