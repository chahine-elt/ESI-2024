# 1ère boucle while

compteur = 1

while(compteur <= 100):
    print(compteur)
    compteur = compteur + 1

print("Terminé !")