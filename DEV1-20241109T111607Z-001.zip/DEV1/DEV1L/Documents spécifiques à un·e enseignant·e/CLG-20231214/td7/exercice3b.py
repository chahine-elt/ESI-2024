nombre_secret = 6

print("L'ordinateur a choisi un nombre entre 1 et 10")
print(" Vous allez devoir le deviner !")

nombre_utilisateur = int(input("Entrez un nombre:"))

while(nombre_utilisateur != nombre_secret):
 nombre_utilisateur = int(input("Raté ! Essayez encore: "))

print("Bravo !")
