# Écrivez un script qui demande un nombre positif n à l’utilisateur et qui affiche tous les
# nombres au carré plus petit ou égal à n.
# Exemple : Si l’utilisateur entre 30, le script affiche : 1 (= 1 ∗ 1), 4 (= 2 ∗ 2), 9 (= 3 ∗ 3),
# 16 (= 4*4) et 25 (= 5*5).

valeur = int(input("Entrez un nombre entier positif : "))

nb = 1
carré = nb*nb

print("les valeurs au carré doivent être plus petites ou égales à : ", valeur)

while(carré <= valeur):
 print("le carré vaut : ", carré)
 nb = nb +1
 carré = nb*nb

