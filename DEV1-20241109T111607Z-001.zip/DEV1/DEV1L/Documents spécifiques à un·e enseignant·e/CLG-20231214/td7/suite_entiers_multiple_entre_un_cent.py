# exercice 2
# les multiples de n compris entre 1 et 100.

nb = int(input("Entrez un nombre entier : "))
     
compteur = 1
while(compteur <= 100):
 if (compteur%nb==0):
  print(compteur)
 compteur = compteur + 1

print("multiples de n compris entre 1 et 100 : Terminé !")