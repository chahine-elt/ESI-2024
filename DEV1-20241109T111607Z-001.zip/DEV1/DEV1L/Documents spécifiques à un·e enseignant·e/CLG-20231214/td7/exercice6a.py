# Canevas d'un script lisant une suite de nombres au clavier
nb_valeurs = 0
valeur = int(input("Entrez une suite de nombre entier positifs, terminez par une valeur négative: "))

while(valeur > -1):
 nb_valeurs = nb_valeurs +1
 # Faire quelque chose avec le contenu de la variable "valeur" ici
 valeur = int(input("Entrez une autre valeur (ou <0 pour terminer): "))

print("Vous avez entré",nb_valeurs,"valeurs")