# exercice 2
# les multiples de 5 qui sont compris entre 1 et n.

compteur = 1

nb = int(input("Entrez un nombre entier : "))

while(compteur <= nb):
 if (compteur%5==0):
  print(compteur)
 compteur = compteur + 1
 

print("multiple de 5 Terminé !")