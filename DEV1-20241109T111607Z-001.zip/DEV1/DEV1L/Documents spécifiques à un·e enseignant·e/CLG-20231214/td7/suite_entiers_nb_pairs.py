# exercice 2
compteur = 1

nb = int(input("Entrez un nombre entier : "))

# nombres pairs
while(compteur <= nb):
    if (compteur%2==0):
        print(compteur)
    compteur = compteur + 1


print("nb pairs Terminé !")