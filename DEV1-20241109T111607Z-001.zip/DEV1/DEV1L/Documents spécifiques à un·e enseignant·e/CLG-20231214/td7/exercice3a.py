import math

nombre = int(input("Veuillez entrer un nombre positif: "))

while(nombre < 0):
 nombre = int(input("Ce nombre n'est pas postif. Veuillez réessayer: "))

print("La racine carrée de", nombre,"est",math.sqrt(nombre))
