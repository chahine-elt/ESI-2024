# Mon 4ème script Python !
#
# Un programme calculant l'aire d'un rectangle de largeur l et de longueur L
# L et l sont entrés au clavier par l'utilisateur

print(" **** Bienvenue ! **** ")
L = int(input("Entrez la longueur du rectangle : "))
l = int(input("Entrez la largeur du rectangle : "))
print("L'aire du rectangle vaut:", L*l)
