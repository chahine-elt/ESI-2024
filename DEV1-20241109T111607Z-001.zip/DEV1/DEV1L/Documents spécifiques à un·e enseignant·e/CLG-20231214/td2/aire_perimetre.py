# Mon 3ème script Python !
#
# Un programme calculant l'aire et le périmètre du cercle dont le
# rayon est entré au clavier par l'utilisateur

print(" **** Bienvenue ! **** ")
r = int(input("Entrez le rayon du cercle : "))
print("L'aire du carré vaut:", 3.14*r**2)
print("Le périmètre du carré vaut:", 2*3.14*r)