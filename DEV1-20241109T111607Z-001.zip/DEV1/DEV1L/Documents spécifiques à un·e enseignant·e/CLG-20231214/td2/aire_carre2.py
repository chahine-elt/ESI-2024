# Mon premier script Python !
#
# Un programme calculant l'aire du carré dont la
# longueur du côté est entrée au clavier par l'utilisateur

print(" **** Bienvenue ! **** ")
# x = input("Entrez la valeur du côté du carré : ")
x = int(input("Entrez la valeur du côté du carré : "))
print("L'aire du carré vaut:", x**2)