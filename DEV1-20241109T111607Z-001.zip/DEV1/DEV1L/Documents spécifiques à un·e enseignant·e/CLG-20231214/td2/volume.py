# Mon second script Python !
#
# Un programme calculant le volume du cube dont la
# longueur du côté est entrée au clavier par l'utilisateur

print(" **** Bienvenue ! **** ")
x = int(input("Entrez la valeur du côté du cube : "))
print("Le volume du cube vaut:", x**3)