#td13

print("*****************TD13**********************")
profs_dev1 = {
 "A111": "bej", "A112": "mbr", "A121": "sre", "A122": "dbo", "A131": "abe",
 "A132": "clg", "A211": "bej", "A212": "cuv", "A221": "sre", "A222": "sdr",
 "A231": "hal", "A232": "nri", "A311": "bis", "A312": "clg", "A321": "cuv",
 "A322": "hal", "A331": "srv", "A332": "gba", "A341": "pbt", "A342": "tni"
}

groupes_par_prof = {
 "abe": 1, "bej": 2, "bis": 1, "clg": 2, "cuv": 2,
 "dbo": 1, "gba": 1, "hal": 2, "mbr": 1, "nri": 1,
 "pbt": 1, "sdr": 1, "sre": 2, "srv": 1, "tni": 1
}

une_personne = {
 "prénom": "Guillaume",
 "nom": "Apollinaire",
 "naissance": (26, 8, 1880)
}

autre_personne = {
 "prénom": "Jean-Jacques",
 "nom": "Goldmann",
 "naissance": (11, 10, 1951)
}

etudiants = {
 52104: {
 "prénom": "Guillaume",
 "nom": "Apollinaire",
 "groupe": "A321"
 },
 45371: {
 "prénom": "Jean-Jacques",
 "nom": "Goldmann",
 "groupe": "A123"
 }
}

print("***********TD13 : exercice1***********")
mon_dictionnaire = {"voiture": "véhicule à quatre roues", "vélo": "véhicule à deux roues"}
print(mon_dictionnaire["voiture"])
print(mon_dictionnaire)

print("***********TD13 : exercice2***********")

#obtenir le prof du groupe A311
print("obtenir le prof du groupe A311 : ", profs_dev1["A311"])

#obtenir le nombre de groupes de Mme Cuvelier (cuv).
print("obtenir le nombre de groupes de Mme Cuvelier (cuv) = ", groupes_par_prof["cuv"])

#obtenir le groupe de l’étudiant ayant le matricule 52104
print("groupe de l'étudiant 52104 : ", etudiants[52104].get("groupe"))

#afficher tou·tes les enseignant·es de dev1 (sans doublons)
print("afficher tou·tes les enseignant·es de dev1 (sans doublons)")
for key in profs_dev1:
 print(profs_dev1[key])

print(" ")
print(" ")

for valeur in profs_dev1.values():
 print(valeur)

print(" ")

unique_values=[]
print("un seule fois chaque prof : ")
for key, value in profs_dev1.items():
 if value not in unique_values:
   unique_values.append(value)

print(unique_values)
 
print(" ")
print("****************** Exercice 3 *********************")
#Exercice 3
# - donner deux valeurs à une même clef ?
# - donner la même valeur à deux clefs différentes ?
# - accéder (par exemple afficher) à une clef 
#    qui n’existe pas dans le dictionnaire ?
# - utiliser une liste comme clef ?
# - utiliser, dans le même dictionnaire, 
#    des clefs de types différents (par exemple une
#    chaîne et un booléen) ?

#- donner deux valeurs à une même clef ?
print("donner deux valeurs à une même clef ?")
mon_dictionnaire = {"voiture": "véhicule à quatre roues", "vélo": "véhicule à deux roues"}
print(mon_dictionnaire)
mon_dictionnaire = {"voiture": "véhicule électrique", "vélo": "véhicule à deux roues"}
print(mon_dictionnaire)
# mon_dictionnaire = {"voiture": "véhicule à quatre roues", "véhicule électrique", "vélo": "véhicule à deux roues"}
# print(mon_dictionnaire)

# - donner la même valeur à deux clefs différentes ?
print("donner la même valeur à deux clefs différentes ?")
mon_dictionnaire = {"voiture": "véhicule à quatre roues", "vélo": "véhicule à quatre roues"}
print(mon_dictionnaire)

# - accéder (par exemple afficher) à une clef 
#    qui n’existe pas dans le dictionnaire ?
print("accéder (par exemple afficher) à une clef qui n’existe pas dans le dictionnaire ?")
print(mon_dictionnaire["voiture"])
# #print(mon_dictionnaire["avion"])

# # - utiliser une liste comme clef ?
print("utiliser une liste comme clef ?")
l=["bonjour", "hallo", "buenos dias"]
print(l)
# #mon_dico = {l: "véhicule à quatre roues", "vélo": "véhicule à quatre roues"}
# #print(mon_dico)

# # - utiliser, dans le même dictionnaire, 
# #    des clefs de types différents (par exemple une
# #    chaîne et un booléen) ?
print("utiliser, dans le même dictionnaire, des clefs de types différents (par exemple une chaîne et un booléen) ?")
mon_dico = {"voiture": "véhicule à quatre roues", 112: "véhicule à deux roues"}
print(mon_dico)
print(mon_dico["voiture"])
print(mon_dico[112])
mon_dico = {"voiture": "véhicule à quatre roues", 112: "véhicule à deux roues"}
print(mon_dico[112])
mon_dico = {123 : "à 6 roues", "voiture": "véhicule à quatre roues", True: "véhicule à deux roues"}
print(mon_dico[True])
print(mon_dico["voiture"])
print(mon_dico[123])

print(" ")
print("****************** Exercice 4 *********************")
print("Écrire un dictionnaire qui à chaque jour (une chaîne : lundi, mardi, etc.), associe sa traduction en anglais. (au besoin, aidez-vous d’un. . . dictionnaire.)")

# Exercice 4 Exercice simple
# Écrire un dictionnaire qui à chaque jour 
#(une chaîne : lundi, mardi, etc.), associe sa
# traduction en anglais. 
#(au besoin, aidez-vous d’un. . . dictionnaire.)
dico_jour = {"lundi":"monday", "mardi":"thuesday", 
             "mercredi":"wednesday", "jeudi":"thursday", 
             "vendredi":"friday", "samedi":"saturday", 
             "dimanche":"sunday"}
print(dico_jour)

print(" ")
print("****************** Exercice 5 ********************* dont les clefs sont les chaînes de la liste, et dont les valeurs comptent les occurrences de chaque clef dans la liste.")
# Exercice 5 
# Construire les fréquences
# Étant donné une liste de chaînes, 
# écrire une fonction qui établit le dictionnaire des
# fréquences de chaque chaîne présente.
# En d’autres termes, créez un dictionnaire 
# dont les clefs sont les chaînes de la liste, et
# dont les valeurs « comptent les occurrences » 
# de chaque clef dans la liste.

profs_dev1 = [
 "bej", "mbr", "sre", "dbo", "abe",
 "clg", "bej", "cuv", "sre", "sdr",
 "hal", "nri", "bis", "clg", "cuv",
 "hal", "srv", "gba", "pbt", "tni"
]


# # Résultat :
# # {
# #  "abe": 1, "bej": 2, "bis": 1, "clg": 2, "cuv": 2,
# #  "dbo": 1, "gba": 1, "hal": 2, "mbr": 1, "nri": 1,
# #  "pbt": 1, "sdr": 1, "sre": 2, "srv": 1, "tni": 1
# #  }

cpt=profs_dev1.count("bej")
print("profs_dev1.count(\"bej"") : ", cpt)

print(profs_dev1)

def construire_fréquences(dico):
  freq = {}
  for items in dico:
   freq[items] = profs_dev1.count(items) 

  print("len(profs_dev1) = ", len(profs_dev1))
  print("len(sorted(freq.items())) = ", len(sorted(freq.items())))
  
  print(" ")
  
  print("{")
  cpt = 0
  for key, value in sorted(freq.items()):
   if cpt < len(sorted(freq.items())) - 1:
    print(f'"{key}" :'+str(value) + ", ", end='')
    cpt=cpt+1
  print(f'"{key}":',value, end='')
  print("\n" + "}")  

print("***********construire_fréquences************")
construire_fréquences(profs_dev1)

print(" ")
print("****************** Exercice 6 : Argmax *********************")
print("Étant donné un dictionnaire dont les valeurs sont des nombres, écrivez une fonction qui détermine la liste des clefs dont la valeur associée est la plus grande.")
# Exercice 6 Argmax
# Étant donné un dictionnaire dont les valeurs sont des nombres, 
# écrivez une fonction qui détermine la liste des clefs 
# dont la valeur associée est la plus grande.

# data = {
#  "abe": 1, "bej": 2, "bis": 1, "clg": 2, "cuv": 2,
#  "dbo": 1, "gba": 1, "hal": 2, "mbr": 1, "nri": 1,
#  "pbt": 1, "sdr": 1, "sre": 2, "srv": 1, "tni": 1
# }

# résultat attendu:
# ["bej", "clg", "cuv", "hal", "sre"]

data = {
 "abe": 1, "bej": 2, "bis": 1, "clg": 2, "cuv": 2,
 "dbo": 1, "gba": 1, "hal": 2, "mbr": 1, "nri": 1,
 "pbt": 1, "sdr": 1, "sre": 2, "srv": 1, "tni": 1
}


def Argmax(dico):
 max_value = max(dico.values())
 clefs_max = [clef for clef, 
              valeur in dico.items() 
              if valeur == max_value]

 return clefs_max

# print(data.values())
# print(max(data.values()))
# max_value = Argmax(data)
print("***********data************")
print(data)
res = Argmax(data)
print(" ")
print("Clefs avec la valeur maximale:")
print(res)


print(" ")
print("****************** Exercice 7 *********************")
print(" Combinaison des précédents : Écrire un programme qui demande des mots à l’utilisateurice (un mot par ligne, et une ligne vide termine l’entrée), puis affiche le ou les mots les plus fréquemment entrés")
# Exercice 7 Combinaison des précédents
# Écrire un programme qui demande des mots à l’utilisateurice 
# (un mot par ligne, et une ligne vide termine l’entrée), 
# puis affiche le ou les mots les plus fréquemment entrés


def mots_plus_frequents():
    # Demander à l'utilisateur de saisir des mots
    print("Entrez un mot par ligne. Appuyez sur Entrée pour terminer l'entrée.")
    mots = []
    mot = input("Mot: ")
    while mot != "":
        mots.append(mot)
        mot = input("Mot: ")

    # Compter la fréquence des mots
    compteur = {}
    for mot in mots:
        compteur[mot] = compteur.get(mot, 0) + 1
        print("mot = ", mot, ", compteur.get(mot, 0) = ", compteur.get(mot, 0), ", compteur[mot] = ", compteur[mot])

    # Trouver la fréquence maximale
    max_frequence = max(compteur.values())

    # Trouver tous les mots avec la fréquence maximale
    mots_max_frequence = [mot for mot, occurrences in compteur.items() if occurrences == max_frequence]

    # Afficher le résultat
    print("\nMot(s) le(s) plus fréquent(s):")
    for mot in mots_max_frequence:
        print(mot) #print(f"{mot} (occurrences: {mots_max_frequence})")

# Appeler la fonction
mots_plus_frequents()
