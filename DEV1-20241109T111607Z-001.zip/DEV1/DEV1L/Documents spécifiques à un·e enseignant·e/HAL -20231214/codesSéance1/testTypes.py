# une variable prend le type de la valeur qu'elle contient

x=3.2
print("x= ", x)
x=True
print("x= ", x)
x="bonjour"
print("x= ", x)
x=5
print("x= ", x)
y=8
print("y= ", y)
som=x+y
print("som = ", som)

