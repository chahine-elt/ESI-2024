# fonction qui teste la parité d'un nombre x 

def is_even(x):
    if x % 2 == 0:
        return True
    else:
        return False


# teste de la fonction is_even en mode NON intéractif car ça fait toujours les mêmes tests. 
    
print("le nombre 11 est-t'il pair ? ", is_even(11))
print("le nombre 8 est-t'il pair ? " , is_even(8))