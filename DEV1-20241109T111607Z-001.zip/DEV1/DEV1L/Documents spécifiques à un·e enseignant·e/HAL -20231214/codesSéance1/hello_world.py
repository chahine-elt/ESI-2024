# programme non intéractif

print("Hello World!")