def is_even(x):
    if x % 2 == 0:
        return True
    else:
        return False
    

x = input("donner la valeur du nombre dont on veut vérifier la parité: ")

x = int(x)

print("le nombre ", x , "est-t'il pair ?", is_even(x))

