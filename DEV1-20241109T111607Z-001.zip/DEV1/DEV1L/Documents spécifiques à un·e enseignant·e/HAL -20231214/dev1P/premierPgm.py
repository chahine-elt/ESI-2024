x = 8 
print("x = ", x)

y = 2 
print("y = ", y)

z = x + y 
print("z = ", z)
