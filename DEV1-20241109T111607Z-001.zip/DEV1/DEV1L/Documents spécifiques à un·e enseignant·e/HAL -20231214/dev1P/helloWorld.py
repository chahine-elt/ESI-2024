print("hello les amis")
