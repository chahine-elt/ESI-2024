x = 3 
y = 2 
z = x + y 
print("z = ", z)
