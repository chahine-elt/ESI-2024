print("Input a number")
s = input() # take keyboard-input from user
s = int(s)  # convert to integer
s = s * s   # square it
print("Its square is", s)
print()

print("What is your name?")
s = input()
s = "Hello " + s + "!"
print(s)