def f1(x):
    print("Hello", x)