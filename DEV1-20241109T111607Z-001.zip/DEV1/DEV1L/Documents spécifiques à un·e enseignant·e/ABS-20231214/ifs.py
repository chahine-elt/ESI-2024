def check_div2_div3(x):
    if x % 2 == 0:
        if x % 3 == 0:
            return "Divisible by 6"
        elif x % 3 == 1:
            return "Even and mod 3 = 1"
        else:
            return "Even and mod 3 = 2"
    else:
        if x % 3 == 0:
            return "Divisible by 3 and not 2"
        elif x % 3 == 1:
            return "Odd and mod 3 = 1"
        else:
            return "Odd and mod 3 = 2"
            
            
for i in range(0, 20):
    print("i:", i, "-", check_div2_div3(i))