def f1(x): # cannot be called
    print("Bye", x)
    
def f1(x):
    print("Bye Bye", x)