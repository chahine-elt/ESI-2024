c = "Hello"

if c: # not the terminator -> not zero -> True
    print("Hello")
if not c:
    print("Not Hello")
    
c = "\0" #escape char with \ -> this is the terminator
if c: # not the terminator -> not zero -> True
    print("Terminator")
if not c:
    print("Not Terminator")
    
c = None
if c: # None -> False
    print("Hello None")    
if not c:
    print("Hello Not None")
   
if c is None: # always test equality with None with 'is'
    print("NoneIS")    
if None == 0: # None is not zero -> False
    print("None == 0")
    
a = "Hello"
b = "Hello" # probably same id as a
if a == b: # content of a is the same as the content of b
    print("a == b")
if a is b:
    print("a is b")
if id(a) == id(b):
    print("id(a) == id(b)")

a = a + " world"
b = b + " world" #probably not the same id as a
if a == b: # content of a is the same as the content of b
    print("a == b")
if a is b:
    print("a is b")
if id(a) == id(b):
    print("id(a) == id(b)")
    
   
l = list(range(-3,3))
print(l)
for i in l:
    if l[i]: # anything not zero is True
        print(l[i])
   
    
