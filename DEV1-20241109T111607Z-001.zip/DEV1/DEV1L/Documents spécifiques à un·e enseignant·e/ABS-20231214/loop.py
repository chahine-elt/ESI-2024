for i in range(-3,5): # for each int in [-3, 5[
    print(i, end=" ")
print()

l = [6,7,8,9,10]
for elem in l:
    print(elem, end=" ")
print()
    
k = 0
while k < len(l):
    print(l[k], end=" ")
    k = k + 1 # if we remove it: infinite loop
print()

while len(l) != 0:
    elem = l.pop() # removes last elem
    print(elem, end=" ")
print()
print(l)
print()

ll = [[1,2,3],[2,3,4,6],[3,4],[4,5,6]]
i = 0 # counter on rows
while i < len(ll):
    j = 0 # counter on columns
    current_list = ll[i]
    while j < len(current_list):
        print(current_list[j], end=" ")
        j = j + 1
    print()
    i = i + 1
print()
    
for i in range(len(ll)):
    current_list = ll[i]
    for j in range(len(current_list)):
        print(current_list[j], end=" ")
    print()
    
    
    
    
    
    
    
  