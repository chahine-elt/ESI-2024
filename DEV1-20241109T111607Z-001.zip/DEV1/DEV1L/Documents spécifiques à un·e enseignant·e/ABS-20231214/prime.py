def is_prime(n):
    d = 2
    while d < n: # checking all divisors lower than n
        if n % d == 0: # if n has a divisor
            return False
        else:
            d = d + 1 # go to next potential divisor
    return True

n = 2
while n <= 29:
    print("Is", n, "is prime?", is_prime(n))
    n = n + 1
