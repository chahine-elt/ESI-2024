def increment(i):
    print("Id of i on fct enter", id(i))
    i = i + 1
    print("Id of i on fct exit", id(i))
    return i
          
n = 3
print(n)
print("id of n before fct", id(n))
n = increment(n)
print(n)
print("id of n after fct", id(n))