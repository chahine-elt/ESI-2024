def increment(l):
    print("Id of l on fct enter", id(l))
    for i in range(len(l)):
        l[i] = l[i] + 1
    print("Id of l on fct exit", id(l))
          
l = [0, 1, 2]
print(l)
print("id of l before fct", id(l))
increment(l)
print(l)
print("id of l after fct", id(l))