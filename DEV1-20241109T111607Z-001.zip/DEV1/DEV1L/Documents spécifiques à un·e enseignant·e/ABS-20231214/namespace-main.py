import namespace1
import namespace2

# f1(2)
namespace1.f1(2)
namespace2.f1(2)